package com.ekutir.farmchalolite.farmchalolite.daoImpl;

import com.ekutir.farmchalolite.farmchalolite.dao.RegistrationDao;

public class RegistrationDaoImpl implements RegistrationDao {

}
