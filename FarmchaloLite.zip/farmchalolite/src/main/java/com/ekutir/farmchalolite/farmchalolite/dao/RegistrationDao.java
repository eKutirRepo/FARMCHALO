package com.ekutir.farmchalolite.farmchalolite.dao;

public interface RegistrationDao {

}
