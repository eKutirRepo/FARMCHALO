package com.ekutir.farmchalolite.farmchalolite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmchaloliteApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmchaloliteApplication.class, args);
	}
}
