package com.ekutir.farmchalolite.farmchalolite.service;

public interface RegistartionService {

}
