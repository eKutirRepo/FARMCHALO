package com.ekutir.farmchalolite.farmchalolite.serviceImpl;

import com.ekutir.farmchalolite.farmchalolite.service.RegistartionService;

public class RegistrationServiceImpl implements RegistartionService{

}
