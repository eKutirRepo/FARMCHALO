package ekutir.farmchaloApp.model;
// Generated Jul 28, 2018 2:34:34 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:55 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "irrigation_type", catalog = "farmchaloApp")
public class IrrigationType implements java.io.Serializable {

	private int irrigationTypeId;
	private String irrigationTypeName;
	private Integer status;
	private Set<LandDetails> landDetailses = new HashSet<LandDetails>(0);

	public IrrigationType() {
	}

	public IrrigationType(int irrigationTypeId, String irrigationTypeName) {
		this.irrigationTypeId = irrigationTypeId;
		this.irrigationTypeName = irrigationTypeName;
	}

	public IrrigationType(int irrigationTypeId, String irrigationTypeName, Integer status,
			Set<LandDetails> landDetailses) {
		this.irrigationTypeId = irrigationTypeId;
		this.irrigationTypeName = irrigationTypeName;
		this.status = status;
		this.landDetailses = landDetailses;
	}

	@Id

	@Column(name = "irrigation_type_id", unique = true, nullable = false)
	public int getIrrigationTypeId() {
		return this.irrigationTypeId;
	}

	public void setIrrigationTypeId(int irrigationTypeId) {
		this.irrigationTypeId = irrigationTypeId;
	}

	@Column(name = "irrigation_type_name", nullable = false, length = 225)
	public String getIrrigationTypeName() {
		return this.irrigationTypeName;
	}

	public void setIrrigationTypeName(String irrigationTypeName) {
		this.irrigationTypeName = irrigationTypeName;
	}

	@Column(name = "status")
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "irrigationType")
	public Set<LandDetails> getLandDetailses() {
		return this.landDetailses;
	}

	public void setLandDetailses(Set<LandDetails> landDetailses) {
		this.landDetailses = landDetailses;
	}

	public enum IrrigationTypeEnum {
		Irregated {
			public String toString() {
				return"Irregated";
			}
		},
		Rainfed {
			public String toString() {
				return"Rainfed";
			}
		};
	}

	public static int getCountryMasterIdByEnum(IrrigationTypeEnum irrigationTypeEnum) {
		switch (irrigationTypeEnum) {
		case Irregated:
			return 1;

		case Rainfed:
			return 2;
		}
		return 0;
	}

	public static String irrigationNameByIdEnum(int i) {
		switch (i) {
		case 1:
			return "Irrigated";
		case 2:
			return "Rainfed";
		}
		return null;
	}

}
