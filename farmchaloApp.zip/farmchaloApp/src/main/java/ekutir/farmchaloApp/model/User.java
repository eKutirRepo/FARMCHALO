package ekutir.farmchaloApp.model;
// Generated Jul 28, 2018 2:34:34 PM by Hibernate Tools 4.3.1

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:32 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "user", catalog = "farmchaloApp")
public class User implements java.io.Serializable {

	private Integer userId;
	private RoleMaster roleMaster;
	private String mobileNo;
	private String password;
	private String firstName;
	private String lastName;
	private String emailId;
	private String businessName;
	private String referenceCode;
	private String aadhaarCard;
	private String profilePic;
	private String imeiNo;
	private Date createdOn;
	private Integer createdBy;
	private Date updatedOn;
	private Integer updatedBy;
	private Integer parentUserId;
	private Boolean status;
	private Set<LandDetails> landDetailses = new HashSet<LandDetails>();
	private Set<UserAddress> userAddresses = new HashSet<UserAddress>();

	public User() {
	}

	public User(String mobileNo, String password, String firstName, String lastName, Date createdOn) {
		this.mobileNo = mobileNo;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.createdOn = createdOn;
	}

	public User(Integer userId, RoleMaster roleMaster, String mobileNo, String password, String firstName,
			String lastName, String emailId, String businessName, String referenceCode, String aadhaarCard,
			String profilePic, String imeiNo, Date createdOn, Integer createdBy, Date updatedOn, Integer updatedBy,
			Integer parentUserId, Boolean status, Set<LandDetails> landDetailses, Set<UserAddress> userAddresses) {
		super();
		this.userId = userId;
		this.roleMaster = roleMaster;
		this.mobileNo = mobileNo;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.businessName = businessName;
		this.referenceCode = referenceCode;
		this.aadhaarCard = aadhaarCard;
		this.profilePic = profilePic;
		this.imeiNo = imeiNo;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.updatedOn = updatedOn;
		this.updatedBy = updatedBy;
		this.parentUserId = parentUserId;
		this.status = status;
		this.landDetailses = landDetailses;
		this.userAddresses = userAddresses;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "user_id", unique = true, nullable = false)
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "role_master_id")
	public RoleMaster getRoleMaster() {
		return this.roleMaster;
	}

	public void setRoleMaster(RoleMaster roleMaster) {
		this.roleMaster = roleMaster;
	}

	@Column(name = "phone_no", nullable = false, length = 225)
	public String getMobileNo() {
		return this.mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Column(name = "password", nullable = false, length = 225)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "first_name", nullable = false, length = 225)
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	@Column(name = "last_name", nullable = false, length = 225)
	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Column(name = "email_id", length = 225)
	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Column(name = "business_name", length = 225)
	public String getBusinessName() {
		return this.businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	@Column(name = "reference_code", length = 225)
	public String getReferenceCode() {
		return this.referenceCode;
	}

	public void setReferenceCode(String referenceCode) {
		this.referenceCode = referenceCode;
	}

	@Column(name = "aadhaar_card", length = 225)
	public String getAadhaarCard() {
		return this.aadhaarCard;
	}

	public void setAadhaarCard(String aadhaarCard) {
		this.aadhaarCard = aadhaarCard;
	}

	@Column(name = "profile_picture", length = 225)
	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	@Column(name = "imei_no", length = 225)
	public String getImeiNo() {
		return this.imeiNo;
	}

	public void setImeiNo(String imeiNo) {
		this.imeiNo = imeiNo;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_on", nullable = false, length = 19)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@Column(name = "created_by")
	public Integer getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_on", length = 19)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	@Column(name = "updated_by")
	public Integer getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Column(name = "parent_user_id")
	public Integer getParentUserId() {
		return parentUserId;
	}

	public void setParentUserId(Integer parentUserId) {
		this.parentUserId = parentUserId;
	}

	@Column(name = "status")
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "user")
	public Set<LandDetails> getLandDetailses() {
		return this.landDetailses;
	}

	public void setLandDetailses(Set<LandDetails> landDetailses) {
		this.landDetailses = landDetailses;
	}

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "user")
	public Set<UserAddress> getUserAddresses() {
		return this.userAddresses;
	}

	public void setUserAddresses(Set<UserAddress> userAddresses) {
		this.userAddresses = userAddresses;
	}

}
