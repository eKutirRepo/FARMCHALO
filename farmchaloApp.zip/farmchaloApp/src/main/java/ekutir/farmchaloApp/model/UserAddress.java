package ekutir.farmchaloApp.model;
// Generated Jul 26, 2018 3:06:45 PM by Hibernate Tools 4.3.1

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:40 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "user_address", catalog = "farmchaloApp")
public class UserAddress implements java.io.Serializable {

	private Integer userAddressId;
	private AddressType addressType;
	private User user;
	private String address1;
	private String block;
	private String city;
	private int district;
	private int pincode;
	private Date createdOn;
	private int createdBy;
	private Date updatedOn;
	private Integer updatedBy;
	private Boolean status;
	private String latitude;
	private String longitude;

	public UserAddress() {
	}

	public UserAddress(AddressType addressType, User user, String address1, String block, int district, int pincode,
			Date createdOn, int createdBy) {
		this.addressType = addressType;
		this.user = user;
		this.address1 = address1;
		this.block = block;
		this.district = district;
		this.pincode = pincode;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
	}

	public UserAddress(AddressType addressType, User user, String address1, String block, String city, int district,
			int pincode, Date createdOn, int createdBy, Date updatedOn, Integer updatedBy, Boolean status,
			String latitude, String longitude) {
		this.addressType = addressType;
		this.user = user;
		this.address1 = address1;
		this.block = block;
		this.city = city;
		this.district = district;
		this.pincode = pincode;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.updatedOn = updatedOn;
		this.updatedBy = updatedBy;
		this.status = status;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "user_address_id", unique = true, nullable = false)
	public Integer getUserAddressId() {
		return this.userAddressId;
	}

	public void setUserAddressId(Integer userAddressId) {
		this.userAddressId = userAddressId;
	}

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "address_type_id", nullable = false)
	public AddressType getAddressType() {
		return this.addressType;
	}

	public void setAddressType(AddressType addressType) {
		this.addressType = addressType;
	}

	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Column(name = "address1", nullable = false, length = 225)
	public String getAddress1() {
		return this.address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	@Column(name = "block", nullable = false, length = 225)
	public String getBlock() {
		return this.block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	@Column(name = "city", length = 225)
	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "district", nullable = false)
	public int getDistrict() {
		return this.district;
	}

	public void setDistrict(int district) {
		this.district = district;
	}

	@Column(name = "pincode", nullable = false)
	public int getPincode() {
		return this.pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_on", nullable = false, length = 19)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@Column(name = "created_by", nullable = false)
	public int getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_on", length = 19)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	@Column(name = "updated_by")
	public Integer getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Column(name = "status")
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@Column(name = "latitude", length = 225)
	public String getLatitude() {
		return this.latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	@Column(name = "longitude", length = 225)
	public String getLongitude() {
		return this.longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

}
