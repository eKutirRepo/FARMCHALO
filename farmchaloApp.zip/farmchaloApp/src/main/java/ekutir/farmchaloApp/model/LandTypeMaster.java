package ekutir.farmchaloApp.model;
// Generated Jul 28, 2018 2:34:34 PM by Hibernate Tools 4.3.1


import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:14 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name="land_type_master"
    ,catalog="farmchaloApp"
    , uniqueConstraints = @UniqueConstraint(columnNames="land_type_name") 
)
public class LandTypeMaster  implements java.io.Serializable {


     private Integer landTypeMasterId;
     private String landTypeName;
     private Boolean status;
     private Set<LandDetails> landDetailses = new HashSet<LandDetails>(0);

    public LandTypeMaster() {
    }

	
    public LandTypeMaster(String landTypeName) {
        this.landTypeName = landTypeName;
    }
    public LandTypeMaster(String landTypeName, Boolean status, Set<LandDetails> landDetailses) {
       this.landTypeName = landTypeName;
       this.status = status;
       this.landDetailses = landDetailses;
    }
   
     @Id @GeneratedValue(strategy=IDENTITY)

    
    @Column(name="land_type_master_id", unique=true, nullable=false)
    public Integer getLandTypeMasterId() {
        return this.landTypeMasterId;
    }
    
    public void setLandTypeMasterId(Integer landTypeMasterId) {
        this.landTypeMasterId = landTypeMasterId;
    }

    
    @Column(name="land_type_name", unique=true, nullable=false, length=225)
    public String getLandTypeName() {
        return this.landTypeName;
    }
    
    public void setLandTypeName(String landTypeName) {
        this.landTypeName = landTypeName;
    }

    
    @Column(name="status")
    public Boolean getStatus() {
        return this.status;
    }
    
    public void setStatus(Boolean status) {
        this.status = status;
    }

@OneToMany(fetch=FetchType.LAZY, mappedBy="landTypeMaster")
    public Set<LandDetails> getLandDetailses() {
        return this.landDetailses;
    }
    
    public void setLandDetailses(Set<LandDetails> landDetailses) {
        this.landDetailses = landDetailses;
    }




}


