package ekutir.farmchaloApp.model;
// Generated Jul 26, 2018 3:06:45 PM by Hibernate Tools 4.3.1

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:49 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "district_master", catalog = "farmchaloApp")
public class DistrictMaster implements java.io.Serializable {

	private Integer districtMasterId;
	private StateMaster stateMaster;
	private String districtName;
	private Boolean status;

	public DistrictMaster() {
	}

	public DistrictMaster(StateMaster stateMaster, String districtName) {
		this.stateMaster = stateMaster;
		this.districtName = districtName;
	}

	public DistrictMaster(StateMaster stateMaster, String districtName, Boolean status) {
		this.stateMaster = stateMaster;
		this.districtName = districtName;
		this.status = status;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "district_master_id", unique = true, nullable = false)
	public Integer getDistrictMasterId() {
		return this.districtMasterId;
	}

	public void setDistrictMasterId(Integer districtMasterId) {
		this.districtMasterId = districtMasterId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "state_master_id", nullable = false)
	public StateMaster getStateMaster() {
		return this.stateMaster;
	}

	public void setStateMaster(StateMaster stateMaster) {
		this.stateMaster = stateMaster;
	}

	@Column(name = "district_name", nullable = false, length = 225)
	public String getDistrictName() {
		return this.districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	@Column(name = "status")
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

}
