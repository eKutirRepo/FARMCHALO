package ekutir.farmchaloApp.model;
// Generated Jul 26, 2018 3:06:45 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:32 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "address_type", catalog = "farmchaloApp")
public class AddressType implements java.io.Serializable {

	private Integer addressTypeId;
	private String addressTypeName;
	private Boolean status;
	private Set<UserAddress> userAddresses = new HashSet<UserAddress>(0);

	public AddressType() {
	}

	public AddressType(String addressTypeName) {
		this.addressTypeName = addressTypeName;
	}

	public AddressType(String addressTypeName, Boolean status, Set<UserAddress> userAddresses) {
		this.addressTypeName = addressTypeName;
		this.status = status;
		this.userAddresses = userAddresses;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "address_type_id", unique = true, nullable = false)
	public Integer getAddressTypeId() {
		return this.addressTypeId;
	}

	public void setAddressTypeId(Integer addressTypeId) {
		this.addressTypeId = addressTypeId;
	}

	@Column(name = "address_type_name", nullable = false, length = 225)
	public String getAddressTypeName() {
		return this.addressTypeName;
	}

	public void setAddressTypeName(String addressTypeName) {
		this.addressTypeName = addressTypeName;
	}

	@Column(name = "status")
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "addressType")
	public Set<UserAddress> getUserAddresses() {
		return this.userAddresses;
	}

	public void setUserAddresses(Set<UserAddress> userAddresses) {
		this.userAddresses = userAddresses;
	}

}
