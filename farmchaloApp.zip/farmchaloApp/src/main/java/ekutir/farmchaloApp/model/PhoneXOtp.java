package ekutir.farmchaloApp.model;
// Generated Jul 26, 2018 3:06:45 PM by Hibernate Tools 4.3.1

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:18 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "phone_x_otp", catalog = "farmchaloApp")
public class PhoneXOtp implements java.io.Serializable {

	private Integer phoneXOtpId;
	private String mobileNo;
	private int otp;
	private Date createdOn;
	private Integer createdBy;
	private Date updatedOn;
	private String updatesBy;

	public PhoneXOtp() {
	}

	public PhoneXOtp(String mobileNo, int otp, Date createdOn) {
		this.mobileNo = mobileNo;
		this.otp = otp;
		this.createdOn = createdOn;
	}

	public PhoneXOtp(String mobileNo, int otp, Date createdOn, Integer createdBy, Date updatedOn, String updatesBy) {
		this.mobileNo = mobileNo;
		this.otp = otp;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.updatedOn = updatedOn;
		this.updatesBy = updatesBy;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "phone_x_otp_id", unique = true, nullable = false)
	public Integer getPhoneXOtpId() {
		return this.phoneXOtpId;
	}

	public void setPhoneXOtpId(Integer phoneXOtpId) {
		this.phoneXOtpId = phoneXOtpId;
	}

	@Column(name = "mobile_no", nullable = false, length = 225)
	public String getMobileNo() {
		return this.mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	@Column(name = "otp", nullable = false)
	public int getOtp() {
		return this.otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_on", nullable = false, length = 19)
	public Date getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@Column(name = "created_by")
	public Integer getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_on", length = 19)
	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	@Column(name = "updates_by", length = 45)
	public String getUpdatesBy() {
		return this.updatesBy;
	}

	public void setUpdatesBy(String updatesBy) {
		this.updatesBy = updatesBy;
	}

}
