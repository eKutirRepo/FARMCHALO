package ekutir.farmchaloApp.model;
// Generated Jul 28, 2018 2:34:34 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:59 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "land_area_master_uom", catalog = "farmchaloApp", uniqueConstraints = @UniqueConstraint(columnNames = "uom"))
public class LandAreaMasterUom implements java.io.Serializable {

	private Integer landAreaMasterUomId;
	private String uom;
	private Boolean status;
	private Set<LandDetails> landDetailses = new HashSet<LandDetails>(0);
	private CountryMaster countryMaster;

	public LandAreaMasterUom() {
	}

	public LandAreaMasterUom(String uom) {
		this.uom = uom;
	}

	public LandAreaMasterUom(String uom, Boolean status, Set<LandDetails> landDetailses, CountryMaster countryMaster) {
		this.uom = uom;
		this.status = status;
		this.landDetailses = landDetailses;
		this.countryMaster = countryMaster;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "land_area_master_uom_id", unique = true, nullable = false)
	public Integer getLandAreaMasterUomId() {
		return this.landAreaMasterUomId;
	}

	public void setLandAreaMasterUomId(Integer landAreaMasterUomId) {
		this.landAreaMasterUomId = landAreaMasterUomId;
	}

	@Column(name = "uom", unique = true, nullable = false, length = 225)
	public String getUom() {
		return this.uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	@Column(name = "status")
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "landAreaMasterUom")
	public Set<LandDetails> getLandDetailses() {
		return this.landDetailses;
	}

	public void setLandDetailses(Set<LandDetails> landDetailses) {
		this.landDetailses = landDetailses;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "country_master_id", nullable = false)
	public CountryMaster getCountryMaster() {
		return countryMaster;
	}

	public void setCountryMaster(CountryMaster countryMaster) {
		this.countryMaster = countryMaster;
	}

}
