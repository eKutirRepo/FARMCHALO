package ekutir.farmchaloApp.model;
// Generated Jul 28, 2018 2:34:34 PM by Hibernate Tools 4.3.1


import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:22 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name="role_master"
    ,catalog="farmchaloApp"
    , uniqueConstraints = @UniqueConstraint(columnNames="role_name") 
)
public class RoleMaster  implements java.io.Serializable {


     private Integer roleMasterId;
     private String roleName;
     private Boolean status;
     private Set<User> users = new HashSet<User>(0);

    public RoleMaster() {
    }

	
    public RoleMaster(String roleName) {
        this.roleName = roleName;
    }
    public RoleMaster(String roleName, Boolean status, Set<User> users) {
       this.roleName = roleName;
       this.status = status;
       this.users = users;
    }
   
     @Id @GeneratedValue(strategy=IDENTITY)

    
    @Column(name="role_master_id", unique=true, nullable=false)
    public Integer getRoleMasterId() {
        return this.roleMasterId;
    }
    
    public void setRoleMasterId(Integer roleMasterId) {
        this.roleMasterId = roleMasterId;
    }

    
    @Column(name="role_name", unique=true, nullable=false, length=225)
    public String getRoleName() {
        return this.roleName;
    }
    
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    
    @Column(name="status")
    public Boolean getStatus() {
        return this.status;
    }
    
    public void setStatus(Boolean status) {
        this.status = status;
    }

@OneToMany(fetch=FetchType.LAZY, mappedBy="roleMaster")
    public Set<User> getUsers() {
        return this.users;
    }
    
    public void setUsers(Set<User> users) {
        this.users = users;
    }




}


