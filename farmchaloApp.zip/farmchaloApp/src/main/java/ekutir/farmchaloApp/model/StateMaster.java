package ekutir.farmchaloApp.model;
// Generated Jul 26, 2018 3:06:45 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:27 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "state_master", catalog = "farmchaloApp", uniqueConstraints = @UniqueConstraint(columnNames = "state_name"))
public class StateMaster implements java.io.Serializable {

	private Integer stateMasterId;
	private CountryMaster countryMaster;
	private String stateName;
	private Boolean status;
	private Set<DistrictMaster> districtMasters = new HashSet<DistrictMaster>(0);

	public StateMaster() {
	}

	public StateMaster(CountryMaster countryMaster, String stateName) {
		this.countryMaster = countryMaster;
		this.stateName = stateName;
	}

	public StateMaster(CountryMaster countryMaster, String stateName, Boolean status,
			Set<DistrictMaster> districtMasters) {
		this.countryMaster = countryMaster;
		this.stateName = stateName;
		this.status = status;
		this.districtMasters = districtMasters;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "state_master_id", unique = true, nullable = false)
	public Integer getStateMasterId() {
		return this.stateMasterId;
	}

	public void setStateMasterId(Integer stateMasterId) {
		this.stateMasterId = stateMasterId;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "country_master_id", nullable = false)
	public CountryMaster getCountryMaster() {
		return this.countryMaster;
	}

	public void setCountryMaster(CountryMaster countryMaster) {
		this.countryMaster = countryMaster;
	}

	@Column(name = "state_name", unique = true, nullable = false, length = 225)
	public String getStateName() {
		return this.stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	@Column(name = "status")
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "stateMaster")
	public Set<DistrictMaster> getDistrictMasters() {
		return this.districtMasters;
	}

	public void setDistrictMasters(Set<DistrictMaster> districtMasters) {
		this.districtMasters = districtMasters;
	}

}
