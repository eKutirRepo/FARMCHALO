package ekutir.farmchaloApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:42 AM
 * 
 */
@Entity
@Table(name = "demo")
public class Demo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "demo")
	private int demo;

	@Column(name = "name")
	private String name;

	public int getDemo() {
		return demo;
	}

	public void setDemo(int demo) {
		this.demo = demo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
