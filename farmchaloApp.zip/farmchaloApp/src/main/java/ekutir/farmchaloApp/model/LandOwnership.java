package ekutir.farmchaloApp.model;
// Generated Jul 28, 2018 2:34:34 PM by Hibernate Tools 4.3.1


import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:07 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name="land_ownership"
    ,catalog="farmchaloApp"
)
public class LandOwnership  implements java.io.Serializable {


     private Integer landOwnershipId;
     private String landOwnershipName;
     private Boolean status;
     private Set<LandDetails> landDetailses = new HashSet<LandDetails>(0);

    public LandOwnership() {
    }

	
    public LandOwnership(String landOwnershipName) {
        this.landOwnershipName = landOwnershipName;
    }
    public LandOwnership(String landOwnershipName, Boolean status, Set<LandDetails> landDetailses) {
       this.landOwnershipName = landOwnershipName;
       this.status = status;
       this.landDetailses = landDetailses;
    }
   
     @Id @GeneratedValue(strategy=IDENTITY)

    
    @Column(name="land_ownership_id", unique=true, nullable=false)
    public Integer getLandOwnershipId() {
        return this.landOwnershipId;
    }
    
    public void setLandOwnershipId(Integer landOwnershipId) {
        this.landOwnershipId = landOwnershipId;
    }

    
    @Column(name="land_ownership_name", nullable=false, length=225)
    public String getLandOwnershipName() {
        return this.landOwnershipName;
    }
    
    public void setLandOwnershipName(String landOwnershipName) {
        this.landOwnershipName = landOwnershipName;
    }

    
    @Column(name="status")
    public Boolean getStatus() {
        return this.status;
    }
    
    public void setStatus(Boolean status) {
        this.status = status;
    }

@OneToMany(fetch=FetchType.LAZY, mappedBy="landOwnership")
    public Set<LandDetails> getLandDetailses() {
        return this.landDetailses;
    }
    
    public void setLandDetailses(Set<LandDetails> landDetailses) {
        this.landDetailses = landDetailses;
    }




}


