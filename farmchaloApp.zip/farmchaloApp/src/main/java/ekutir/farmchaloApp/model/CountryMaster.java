package ekutir.farmchaloApp.model;
// Generated Jul 26, 2018 3:06:45 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:38 AM
 * 
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "country_master", catalog = "farmchaloApp", uniqueConstraints = @UniqueConstraint(columnNames = "country_name"))
public class CountryMaster implements java.io.Serializable {

	private Integer countryMasterId;
	private String countryName;
	private Boolean status;
	private Set<StateMaster> stateMasters = new HashSet<StateMaster>(0);
	private Set<LandAreaMasterUom> landAreaMasterUom = new HashSet<LandAreaMasterUom>(0);

	public CountryMaster() {
	}

	public CountryMaster(String countryName) {
		this.countryName = countryName;
	}

	public CountryMaster(String countryName, Boolean status, Set<StateMaster> stateMasters,
			Set<LandAreaMasterUom> landAreaMasterUom) {
		this.countryName = countryName;
		this.status = status;
		this.stateMasters = stateMasters;
		this.landAreaMasterUom = landAreaMasterUom;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "country_master_id", unique = true, nullable = false)
	public Integer getCountryMasterId() {
		return this.countryMasterId;
	}

	public void setCountryMasterId(Integer countryMasterId) {
		this.countryMasterId = countryMasterId;
	}

	@Column(name = "country_name", unique = true, nullable = false, length = 225)
	public String getCountryName() {
		return this.countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	@Column(name = "status")
	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "countryMaster")
	public Set<StateMaster> getStateMasters() {
		return this.stateMasters;
	}

	public void setStateMasters(Set<StateMaster> stateMasters) {
		this.stateMasters = stateMasters;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "countryMaster")
	public Set<LandAreaMasterUom> getLandAreaMasterUom() {
		return landAreaMasterUom;
	}

	public void setLandAreaMasterUom(Set<LandAreaMasterUom> landAreaMasterUom) {
		this.landAreaMasterUom = landAreaMasterUom;
	}

	public enum CountryMasterEnum {
		INDIA, NEPAL
	}

	public static int getCountryMasterIdByEnum(CountryMasterEnum cMaterEnum) {
		switch (cMaterEnum) {
		case INDIA:
			return 1;

		case NEPAL:
			return 2;
		}
		return 0;
	}

	public static CountryMasterEnum getCountryEnumById(int i) {
		switch (i) {
		case 1:
			return CountryMasterEnum.INDIA;
		case 2:
			return CountryMasterEnum.NEPAL;
		}
		return null;
	}

}
