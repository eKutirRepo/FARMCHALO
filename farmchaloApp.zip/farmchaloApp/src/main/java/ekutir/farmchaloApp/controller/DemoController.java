package ekutir.farmchaloApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ekutir.farmchaloApp.model.Demo;
import ekutir.farmchaloApp.service.DemoService;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:39:27 AM
 * 
 */
@RestController
@RequestMapping("/")
@CrossOrigin(origins = { "*" }, maxAge = 3600L)
public class DemoController {

	@Autowired
	DemoService demoService;

	@RequestMapping(value = "/")
	public String index() {
		System.out.println("index method called");
		return "login";
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/demo", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity demo() {
		Demo demo = new Demo();

		demo.setName("Rutvij");
		demoService.saveDemo(demo);

		return null;
	}
}
