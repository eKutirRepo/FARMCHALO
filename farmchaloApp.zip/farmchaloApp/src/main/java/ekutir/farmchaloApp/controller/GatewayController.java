package ekutir.farmchaloApp.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ekutir.farmchaloApp.dto.CountryDto;
import ekutir.farmchaloApp.dto.CountryMasterDto;
import ekutir.farmchaloApp.dto.DistrictDto;
import ekutir.farmchaloApp.dto.GenericDto;
import ekutir.farmchaloApp.dto.PhoneXOtpDto;
import ekutir.farmchaloApp.dto.RegistrationDto;
import ekutir.farmchaloApp.dto.StateDto;
import ekutir.farmchaloApp.dto.StateMasterDto;
import ekutir.farmchaloApp.dto.StatusDto;
import ekutir.farmchaloApp.dto.UserDto;
import ekutir.farmchaloApp.model.PhoneXOtp;
import ekutir.farmchaloApp.service.GatewayService;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:39:45 AM
 * 
 */
@RestController
@RequestMapping("/")
@CrossOrigin(origins = { "*" }, maxAge = 3600L)
public class GatewayController {

	@Autowired
	GatewayService gatewayService;
	
	@Autowired
	HttpServletRequest request;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/generateOtp", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity generateOtp(@RequestBody PhoneXOtp phoneXotp) {
		StatusDto status = new StatusDto();
		PhoneXOtpDto phoneXotpDto = null;
		try {
			phoneXotpDto = gatewayService.generateOtp(phoneXotp);
			status = phoneXotpDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			phoneXotpDto.setStatus(status);
			return new ResponseEntity(phoneXotpDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			phoneXotpDto.setStatus(status);
			return new ResponseEntity(phoneXotpDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/verifyMobileNo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity verifyMobileNo(@RequestBody PhoneXOtp phoneXotp) {
		StatusDto status = new StatusDto();
		PhoneXOtpDto phoneXotpDto = null;
		try {
			phoneXotpDto = gatewayService.verifyMobileNo(phoneXotp);
			status = phoneXotpDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			phoneXotpDto.setStatus(status);
			return new ResponseEntity(phoneXotpDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			phoneXotpDto.setStatus(status);
			return new ResponseEntity(phoneXotpDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/varifyOtp", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity varifyOtp(@RequestBody PhoneXOtp phoneXotp) {
		StatusDto status = new StatusDto();
		PhoneXOtpDto phoneXotpDto = null;
		try {
			phoneXotpDto = gatewayService.varifyOtp(phoneXotp);
			status = phoneXotpDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			phoneXotpDto.setStatus(status);
			return new ResponseEntity(phoneXotpDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			phoneXotpDto.setStatus(status);
			return new ResponseEntity(phoneXotpDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/resendOtp", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity resendOtp(@RequestBody PhoneXOtp phoneXotp) {
		StatusDto status = new StatusDto();
		PhoneXOtpDto phoneXotpDto = null;
		try {
			phoneXotpDto = gatewayService.resendOtp(phoneXotp);
			status = phoneXotpDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			phoneXotpDto.setStatus(status);
			return new ResponseEntity(phoneXotpDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			phoneXotpDto.setStatus(status);
			return new ResponseEntity(phoneXotpDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity registerUser(@RequestBody RegistrationDto registerationDto) {
		StatusDto status = new StatusDto();
		UserDto userInfo = null;
		try {
			registerationDto.setPath("/opt/tomcat/webapps/farmchaloApp/Images/temp.png");
			userInfo = gatewayService.registerUser(registerationDto);
			status = userInfo.getStatusDto();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			userInfo.setStatusDto(status);
			return new ResponseEntity(userInfo, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
//			userInfo.setStatusDto(status);
			return new ResponseEntity(userInfo, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/getAllCountries", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getAllCountries() {
		StatusDto status = new StatusDto();
		try {
			CountryDto countryDto = gatewayService.getAllCountries();
			status = countryDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			countryDto.setStatus(status);
			return new ResponseEntity(countryDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			return new ResponseEntity(status, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/getSateByCountry", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getSateByCountry(@RequestBody CountryMasterDto countryMasterDto) {
		GenericDto genericDto = new GenericDto();
		StatusDto status = new StatusDto();
		try {
			StateDto stateDto = gatewayService.getSateByCountry(countryMasterDto);
			status = stateDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			stateDto.setStatus(status);
			return new ResponseEntity(stateDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();

			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(genericDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/getDistrictByState", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getDistrictByState(@RequestBody StateMasterDto stateMasterdto) {
		GenericDto genericDto = new GenericDto();
		StatusDto status = new StatusDto();
		try {
			DistrictDto districtDto = gatewayService.getDistrictByState(stateMasterdto);
			status = districtDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");

			districtDto.setStatus(status);
			return new ResponseEntity(districtDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();

			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(status, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/forgetPassword", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity forgetPassword(@RequestBody RegistrationDto registrationDto) {
		GenericDto genericDto = new GenericDto();
		StatusDto status = new StatusDto();
		try {
			status = gatewayService.forgetPassword(registrationDto);
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			
			return new ResponseEntity(status, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();

			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(status, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity login(@RequestBody RegistrationDto registrationDto) {
		GenericDto genericDto = new GenericDto();
		StatusDto status = new StatusDto();
		try {
			UserDto userDto = gatewayService.login(registrationDto);
			status = userDto.getStatusDto();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			userDto.setStatusDto(status);
			return new ResponseEntity(userDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();

			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(status, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/meInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity meInfo(@RequestBody RegistrationDto registrationDto) {
		GenericDto genericDto = new GenericDto();
		StatusDto status = new StatusDto();
		try {
			RegistrationDto meInfo = gatewayService.meInfo(registrationDto);
			status = meInfo.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			meInfo.setStatus(status);
			return new ResponseEntity(meInfo, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();

			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(status, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/editMeInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity editInfo(@RequestBody RegistrationDto registrationDto) {
		GenericDto genericDto = new GenericDto();
		StatusDto status = new StatusDto();
		try {
			RegistrationDto meInfo = gatewayService.editInfo(registrationDto);
			status = meInfo.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			meInfo.setStatus(status);
			return new ResponseEntity(meInfo, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();

			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(status, HttpStatus.BAD_REQUEST);
		}
	}

}
