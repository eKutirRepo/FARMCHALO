package ekutir.farmchaloApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import ekutir.farmchaloApp.dto.FarmerRegisterationDto;
import ekutir.farmchaloApp.dto.GenericDto;
import ekutir.farmchaloApp.dto.LandAreaMasterUomDto;
import ekutir.farmchaloApp.dto.LandDetailsDto;
import ekutir.farmchaloApp.dto.LandDto;
import ekutir.farmchaloApp.dto.MyFarmersDto;
import ekutir.farmchaloApp.dto.StatusDto;
import ekutir.farmchaloApp.service.FarmerService;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:39:35 AM
 * 
 */
@RestController
@RequestMapping("/")
@CrossOrigin(origins = { "*" }, maxAge = 3600L)
public class FarmerController {

	@Autowired
	FarmerService farmerService;

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/farmerRegistration", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity farmerRegistration(@RequestBody FarmerRegisterationDto farmerRegistrationDto) {
		StatusDto status = new StatusDto();
		FarmerRegisterationDto farmerDto = null;
		try {
			farmerDto = farmerService.farmerRegistration(farmerRegistrationDto);
			status = farmerDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			farmerDto.setStatus(status);
			return new ResponseEntity(farmerDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			farmerDto.setStatus(status);
			return new ResponseEntity(farmerDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/getLandInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity getLandInfo(@RequestBody LandAreaMasterUomDto landAreaMasterUomDto) {
		StatusDto status = new StatusDto();
		GenericDto genericDto = new GenericDto();
		try {
			LandDto landDto = farmerService.getLandInfo(landAreaMasterUomDto);
			status = landDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			landDto.setStatus(status);
			return new ResponseEntity(landDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(genericDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/fetchMyFarmers", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity fetchMyFarmers(@RequestBody FarmerRegisterationDto farmerRegistrationDto) {
		StatusDto status = new StatusDto();
		GenericDto genericDto = new GenericDto();
		try {
			MyFarmersDto myFarmersDto = new MyFarmersDto();
			myFarmersDto = farmerService.fetchMyFarmers(farmerRegistrationDto);
			status = myFarmersDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			myFarmersDto.setStatus(status);
			return new ResponseEntity(myFarmersDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(genericDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/fetchFarmerInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity fetchFarmerInfo(@RequestBody FarmerRegisterationDto farmerRegistrationDto) {
		StatusDto status = new StatusDto();
		GenericDto genericDto = new GenericDto();
		try {
			FarmerRegisterationDto farmerDto = farmerService.fetchFarmerInfo(farmerRegistrationDto);
			status = farmerDto.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			farmerDto.setStatus(status);
			return new ResponseEntity(farmerDto, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(genericDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/addFarmersLand", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity addFarmersLand(@RequestBody LandDetailsDto landDetailsDto) {
		StatusDto status = new StatusDto();
		GenericDto genericDto = new GenericDto();
		try {
			LandDetailsDto landDetail = farmerService.addFarmersLand(landDetailsDto);
			status = landDetail.getStatusDto();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			landDetail.setStatusDto(status);
			return new ResponseEntity(landDetail, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(genericDto, HttpStatus.BAD_REQUEST);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/editFarmerInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity editFarmerInfo(@RequestBody FarmerRegisterationDto farmerRegistrationDto) {
		StatusDto status = new StatusDto();
		GenericDto genericDto = new GenericDto();
		try {
			FarmerRegisterationDto farmerInfo = farmerService.editFarmerInfo(farmerRegistrationDto);
			status = farmerInfo.getStatus();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			farmerInfo.setStatus(status);
			return new ResponseEntity(farmerInfo, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(genericDto, HttpStatus.BAD_REQUEST);
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/editFarmerLand", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity editFarmerLand(@RequestBody LandDetailsDto landDetailsDto) {
		StatusDto status = new StatusDto();
		GenericDto genericDto = new GenericDto();
		try {
			LandDetailsDto landDetail = farmerService.editFarmerLand(landDetailsDto);
			status = landDetail.getStatusDto();
			status.setStatusCode(Integer.parseInt(HttpStatus.OK.toString()));
			status.setStatusMessage("OK");
			landDetail.setStatusDto(status);
			return new ResponseEntity(landDetail, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatusCode(Integer.parseInt(HttpStatus.BAD_REQUEST.toString()));
			status.setStatusMessage("BAD_REQUEST");
			genericDto.setStatus(status);
			return new ResponseEntity(genericDto, HttpStatus.BAD_REQUEST);
		}
	}
}
