package ekutir.farmchaloApp.dao;

import java.util.List;

import ekutir.farmchaloApp.model.DistrictMaster;
import ekutir.farmchaloApp.model.IrrigationType;
import ekutir.farmchaloApp.model.LandAreaMasterUom;
import ekutir.farmchaloApp.model.LandOwnership;
import ekutir.farmchaloApp.model.LandTypeMaster;
import ekutir.farmchaloApp.model.User;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:40:06 AM
 * 
 */
public interface FarmerDao {

	List<User> fetchUserByMobileNo(String mobileNo);

	User saveOrUpdateUser(User user);

	List<IrrigationType> fetchAllIrrigationTypes();

	List<LandAreaMasterUom> fetchAllLandAreaMasterUoms();

	List<LandOwnership> fetchAllLandOwnerships();

	List<LandTypeMaster> fetchAllLandTypeMasters();

	List<User> fetchUserByUserId(int userId);

	List<User> fetchFarmersByMeId(int userId);

	List<DistrictMaster> fetchDistrictByDistrictId(int district);

}
