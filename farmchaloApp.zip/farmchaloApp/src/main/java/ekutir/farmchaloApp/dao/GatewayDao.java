package ekutir.farmchaloApp.dao;

import java.util.List;

import ekutir.farmchaloApp.model.AddressType;
import ekutir.farmchaloApp.model.CountryMaster;
import ekutir.farmchaloApp.model.DistrictMaster;
import ekutir.farmchaloApp.model.PhoneXOtp;
import ekutir.farmchaloApp.model.StateMaster;
import ekutir.farmchaloApp.model.User;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:40:12 AM
 * 
 */
public interface GatewayDao {

	List<User> fetchUserByMobileNo(String mobileNo);

	void saveOrUpdatePhoneXOtp(PhoneXOtp phoneXotp);

	List<PhoneXOtp> fetchPhoneXOtpByMobileNo(String mobileNo);

	void deletePhoneXOtp(PhoneXOtp phoneOTP);

	User saveOrUpdateUser(User user);

	List<CountryMaster> fetchAllCountries();

	List<StateMaster> fetchAllStatesByCountryId(int countryMasterId);

	List<DistrictMaster> fetchDistrictByStateId(int stateMasterId);

	AddressType fetchAddressType(int i);

	List<User> fetchUserByUserId(Integer userId);

	DistrictMaster fetchDistrictByDistrictId(int district);

}
