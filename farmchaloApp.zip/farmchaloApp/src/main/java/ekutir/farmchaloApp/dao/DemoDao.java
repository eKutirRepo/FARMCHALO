package ekutir.farmchaloApp.dao;

import ekutir.farmchaloApp.model.Demo;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:39:58 AM
 * 
 */
public interface DemoDao {

	void saveDemo(Demo demo);

}
