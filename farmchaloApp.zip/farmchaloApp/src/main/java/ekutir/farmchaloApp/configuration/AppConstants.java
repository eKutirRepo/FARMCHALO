package ekutir.farmchaloApp.configuration;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:39:02 AM
 * 
 */
public class AppConstants {

	public static final String COUNTRY = "NEPAL";
	public static final String COUNTRY_CODE = "+977";
	public static final String TIME_ZONE = "NPT";
	public static final int INDIAN_MOBILE_NO_LENGTH = 10;
	public static final String OTP_URL = "http://2factor.in/API/V1/{apiKey}/SMS/" + COUNTRY_CODE
			+ "{phoneNumber}/{otp}";
	public static final String AWS_FILE_FORMAT = ".png";
	public static final String AWS_BUCKET_NAME = "farmchalodemo/profilepictures";
	public static final String AWS_REGION = "ap-south-1";
	public static final String AWS_DEFAULT_URL = "https://s3." + AWS_REGION + ".amazonaws.com/";
	public static final String AWS_KEY_ID = "AKIAJ6CJXKFXUWOV4WVA";
	public static final String AWS_ACCESS_KEY = "6fvF+mSS4nQ6RA//cPwII3FHpRaVAW0mlNED3w4G";
	
	public static final String MESSAGE_API = "136260fb-29b8-11e7-929b-00163ef91450";
	public static final String PHONE_NUMBER_ACCEPTED_STATUS_CODE = "PHONE_NUMBER_ACCEPTED";
	public static final String PHONE_NUMBER_ACCEPTED_AND_OTP_SENT_STATUS_MESSAGE = "OTP has been sent successfully to the entered mobile number. Please verify your mobile number.";
	public static final String RESEND_OTP_SUCCESSFUL = "OTP has been sent to the registered mobile number.";
	public static final String OTP_NOT_SEND = "OTP_NOT_SEND";
	public static final String OTP_NOT_SEND_MESSAGE = "There is some problem to send an otp. Try it again";
	public static final String USER_ALREADY_REGISTERED = "USER_ALREADY_REGISTERED";
	public static final String LOGIN_SUCCESSFUL = "Login Successfully";
	public static final String USER_ALREADY_REGISTERED_MESSAGE = "User is already Registered";
	public static final String OTP_ALREADY_GENERATED = "OTP_ALREADY_GENERATED";
	public static final String OTP_ALREADY_GENERATED_MESSAGE = "Otp is already Generated";
	public static final String INVALID_MOBILE_NO = "INVALID_MOBILE_NO";
	public static final String INVALID_MOBILE_NO_MESSAGE = "Please Enter valid Mobile Number";
	public static final String ENTER_MOBILE_NUMBER = "ENTER_MOBILE_NUMBER";
	public static final String ENTER_MOBILE_NUMBER_MESSAGE = "Please Enter Mobile Number";
	public static final String ERROR = "ERROR";
	public static final String ERROR_MESSAGE = "There is some Error in Server";
	public static final String OTP_VARIFIED = "OTP_VARIFIED";
	public static final String OTP_VARIFIED_MESSAGE = "Otp varified. Please register yourself";
	public static final String OTP_NOT_GENERATED = "OTP_NOT_GENERATED";
	public static final String OTP_NOT_GENERATED_MESSAGE = "Otp is not generated yet";
	public static final String OTP_NOT_VARIFIED = "OTP_NOT_VARIFIED";
	public static final String OTP_NOT_VARIFIED_MESSAGE = "Otp is not Correct";
	public static final String REGISTRATION_PROCESS_COMPLETED = "REGISTRATION_PROCESS_COMPLETED";
	public static final String REGISTRATION_PROCESS_COMPLETED_MESSAGE = "Registration process completed.";
	public static final String MOBILE_NO_NOT_REGISTERED = "Mobile number is not registered.";
	public static final String PASSWORD_CHANGED_SUCCESSFULLY = "Password changed Successfully";
	public static final String LOGIN_FAILED = "Please Enter correct Password";
	public static final String SUCCESSFULL_MESSAGE = "Successfull";
	public static final String LAND_ADDED_SUCCESSFULLY = "New land added successfully.";
	public static final String LAND_EDITED_SUCCESSFULLY = "Land edited successfully.";
	public static final String USER_NOT_REGISTERED = "User is not Registered yet.";
	public static final String NO_FARMERS = "None of the Farmers are registered by You.";
	public static final String FARMER_ALREADY_REGISTERED = " is already registered as Farmer.";
	public static final String USER_ALREADY_REGISTERED_AS_ME = " number is already registered as ME";
	public static final String FARMER_NOT_REGISTERED = "Farmer is not Registered yet.";
	public static final String PROFILE_EDITED_SUCCESSFULLY = "Profile edited successfully";
	public static final String FARMER_EDITED_SUCCESSFULLY = "Farmer's profile edited successfully";
	public static final String NOT_FARMER = "You are not Farmer ;)";
	public static final String NOT_ME = "You are Farmer";
}
