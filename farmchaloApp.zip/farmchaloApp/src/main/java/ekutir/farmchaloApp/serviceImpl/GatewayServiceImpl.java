package ekutir.farmchaloApp.serviceImpl;

import ekutir.farmchaloApp.dao.GatewayDao;
import ekutir.farmchaloApp.dto.CountryDto;
import ekutir.farmchaloApp.dto.CountryMasterDto;
import ekutir.farmchaloApp.dto.DistrictDto;
import ekutir.farmchaloApp.dto.DistrictMasterDto;
import ekutir.farmchaloApp.dto.PhoneXOtpDto;
import ekutir.farmchaloApp.dto.RegistrationDto;
import ekutir.farmchaloApp.dto.StateDto;
import ekutir.farmchaloApp.dto.StateMasterDto;
import ekutir.farmchaloApp.dto.StatusDto;
import ekutir.farmchaloApp.dto.UserDto;
import ekutir.farmchaloApp.model.AddressType;
import ekutir.farmchaloApp.model.CountryMaster;
import ekutir.farmchaloApp.model.DistrictMaster;
import ekutir.farmchaloApp.model.PhoneXOtp;
import ekutir.farmchaloApp.model.RoleMaster;
import ekutir.farmchaloApp.model.StateMaster;
import ekutir.farmchaloApp.model.User;
import ekutir.farmchaloApp.model.UserAddress;
import ekutir.farmchaloApp.service.GatewayService;
import ekutir.utilities.CommonUtilities;

import static ekutir.farmchaloApp.configuration.AppConstants.*;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:45:17 AM
 * 
 */
@Service
public class GatewayServiceImpl implements GatewayService {

	@Autowired
	GatewayDao gatewayDao;

	@Autowired
	private AmazonS3 s3client;

	@Override
	public PhoneXOtpDto generateOtp(PhoneXOtp phoneXotp) {
		PhoneXOtpDto phoneXotpDto = new PhoneXOtpDto();
		StatusDto status = new StatusDto();
		try {
			if (!(phoneXotp.getMobileNo() == null && phoneXotp.getMobileNo().isEmpty())) {
				if (phoneXotp.getMobileNo().length() == INDIAN_MOBILE_NO_LENGTH) {
					List<PhoneXOtp> pxo = gatewayDao.fetchPhoneXOtpByMobileNo(phoneXotp.getMobileNo());
					if (pxo.isEmpty()) {
						List<User> user = gatewayDao.fetchUserByMobileNo(phoneXotp.getMobileNo());
						if (user.isEmpty()) {
							int otp = CommonUtilities.generateOtp();
							phoneXotp.setOtp(otp);
							phoneXotp.setCreatedOn(CommonUtilities.currentDateTime());
							gatewayDao.saveOrUpdatePhoneXOtp(phoneXotp);

							if (CommonUtilities.sendOtp(phoneXotp.getMobileNo(), otp)) {
								status.setStatus(1);
								status.setMessage(PHONE_NUMBER_ACCEPTED_AND_OTP_SENT_STATUS_MESSAGE);
							} else {
								status.setStatus(0);
								status.setMessage(OTP_NOT_SEND_MESSAGE);
							}

						} else {
							User farmerInfo = user.get(0);
							if (farmerInfo.getRoleMaster().getRoleMasterId() == 1) {
								status.setStatus(0);
								status.setMessage(phoneXotp.getMobileNo() + USER_ALREADY_REGISTERED_AS_ME);
							} else {
								status.setStatus(0);
								status.setMessage(phoneXotp.getMobileNo() + FARMER_ALREADY_REGISTERED);
							}
						}
					} else {
						int otp = CommonUtilities.generateOtp();
						PhoneXOtp phone = pxo.get(0);
						phone.setOtp(otp);
						phone.setUpdatedOn(CommonUtilities.currentDateTime());

						gatewayDao.saveOrUpdatePhoneXOtp(phone);
						if (CommonUtilities.sendOtp(phoneXotp.getMobileNo(), otp)) {
							status.setStatus(1);
							status.setMessage(PHONE_NUMBER_ACCEPTED_AND_OTP_SENT_STATUS_MESSAGE);
						} else {
							status.setStatus(0);
							status.setMessage(OTP_NOT_SEND_MESSAGE);
						}
					}
				} else {
					status.setStatus(0);
					status.setMessage(INVALID_MOBILE_NO_MESSAGE);
				}
			} else {
				status.setStatus(0);
				status.setMessage(ENTER_MOBILE_NUMBER_MESSAGE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}

		phoneXotpDto.setStatus(status);

		return phoneXotpDto;
	}

	@Override
	public PhoneXOtpDto verifyMobileNo(PhoneXOtp phoneXotp) {
		PhoneXOtpDto phoneXotpDto = new PhoneXOtpDto();
		StatusDto status = new StatusDto();
		try {
			if (!(phoneXotp.getMobileNo() == null && phoneXotp.getMobileNo().isEmpty())) {
				if (phoneXotp.getMobileNo().length() == INDIAN_MOBILE_NO_LENGTH) {
					List<PhoneXOtp> pxo = gatewayDao.fetchPhoneXOtpByMobileNo(phoneXotp.getMobileNo());
					if (pxo.isEmpty()) {
						if (!gatewayDao.fetchUserByMobileNo(phoneXotp.getMobileNo()).isEmpty()) {
							int otp = CommonUtilities.generateOtp();
							phoneXotp.setOtp(otp);
							phoneXotp.setCreatedOn(CommonUtilities.currentDateTime());
							gatewayDao.saveOrUpdatePhoneXOtp(phoneXotp);

							if (CommonUtilities.sendOtp(phoneXotp.getMobileNo(), otp)) {
								status.setStatus(1);
								status.setMessage(PHONE_NUMBER_ACCEPTED_AND_OTP_SENT_STATUS_MESSAGE);
							} else {
								status.setStatus(0);
								status.setMessage(OTP_NOT_SEND_MESSAGE);
							}

						} else {
							status.setStatus(0);
							status.setMessage(phoneXotp.getMobileNo() + " " + MOBILE_NO_NOT_REGISTERED);
						}
					} else {
						int otp = CommonUtilities.generateOtp();
						PhoneXOtp phone = pxo.get(0);
						phone.setOtp(otp);
						phone.setUpdatedOn(CommonUtilities.currentDateTime());

						gatewayDao.saveOrUpdatePhoneXOtp(phone);
						if (CommonUtilities.sendOtp(phoneXotp.getMobileNo(), otp)) {
							status.setStatus(1);
							status.setMessage(PHONE_NUMBER_ACCEPTED_AND_OTP_SENT_STATUS_MESSAGE);
						} else {
							status.setStatus(0);
							status.setMessage(OTP_NOT_SEND_MESSAGE);
						}
					}
				} else {
					status.setStatus(0);
					status.setMessage(INVALID_MOBILE_NO_MESSAGE);
				}
			} else {
				status.setStatus(0);
				status.setMessage(ENTER_MOBILE_NUMBER_MESSAGE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}

		phoneXotpDto.setStatus(status);

		return phoneXotpDto;
	}

	@Override
	public PhoneXOtpDto varifyOtp(PhoneXOtp phoneXotp) {
		PhoneXOtpDto phoneXotpDto = new PhoneXOtpDto();
		StatusDto status = new StatusDto();
		try {
			if (!(phoneXotp.getMobileNo() == null && phoneXotp.getMobileNo().isEmpty())) {
				if (phoneXotp.getMobileNo().length() == INDIAN_MOBILE_NO_LENGTH) {
					List<PhoneXOtp> phoneOtpList = gatewayDao.fetchPhoneXOtpByMobileNo(phoneXotp.getMobileNo());
					if ((!phoneOtpList.isEmpty())) {
						PhoneXOtp phoneOTP = phoneOtpList.get(0);
						if (phoneOTP.getOtp() == phoneXotp.getOtp()) {
							status.setStatus(1);
							status.setMessage(OTP_VARIFIED_MESSAGE);
							gatewayDao.deletePhoneXOtp(phoneOTP);
						} else {
							status.setStatus(0);
							status.setMessage(OTP_NOT_VARIFIED_MESSAGE);
						}
					} else {
						status.setStatus(0);
						status.setMessage(OTP_NOT_GENERATED_MESSAGE);
					}
				} else {
					status.setStatus(0);
					status.setMessage(INVALID_MOBILE_NO_MESSAGE);
				}
			} else {
				status.setStatus(0);
				status.setMessage(ENTER_MOBILE_NUMBER_MESSAGE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}

		phoneXotpDto.setStatus(status);

		return phoneXotpDto;
	}

	@Override
	public PhoneXOtpDto resendOtp(PhoneXOtp phoneXotp) {
		PhoneXOtpDto phoneXotpDto = new PhoneXOtpDto();
		StatusDto status = new StatusDto();
		try {
			if (!(phoneXotp.getMobileNo() == null && phoneXotp.getMobileNo().isEmpty())) {
				if (phoneXotp.getMobileNo().length() == INDIAN_MOBILE_NO_LENGTH) {
					List<PhoneXOtp> phoneOtpList = gatewayDao.fetchPhoneXOtpByMobileNo(phoneXotp.getMobileNo());
					if ((!phoneOtpList.isEmpty())) {
						PhoneXOtp phoneOTP = phoneOtpList.get(0);
						if (CommonUtilities.sendOtp(phoneXotp.getMobileNo(), phoneOTP.getOtp())) {
							status.setStatus(1);
							status.setMessage(RESEND_OTP_SUCCESSFUL);
						} else {
							status.setStatus(0);
							status.setMessage(OTP_NOT_SEND_MESSAGE);
						}

					} else {
						status.setStatus(0);
						status.setMessage(OTP_NOT_GENERATED_MESSAGE);
					}
				} else {
					status.setStatus(0);
					status.setMessage(INVALID_MOBILE_NO_MESSAGE);
				}
			} else {
				status.setStatus(0);
				status.setMessage(ENTER_MOBILE_NUMBER_MESSAGE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}

		phoneXotpDto.setStatus(status);

		return phoneXotpDto;
	}

	@Override
	public UserDto registerUser(RegistrationDto registerationDto) {
		UserDto userDto = new UserDto();
		StatusDto status = new StatusDto();
		try {

			System.out.println(registerationDto.getLatitude() + " " + registerationDto.getLongitude());
			if (registerationDto.getMobileNo() != null) {
				if (registerationDto.getMobileNo().length() == INDIAN_MOBILE_NO_LENGTH) {
					List<User> userInfo = gatewayDao.fetchUserByMobileNo(registerationDto.getMobileNo());
					if (userInfo.isEmpty()) {
						User user = new User();
						Set<UserAddress> userAddress = new HashSet<UserAddress>();
						UserAddress address = new UserAddress();
						address.setAddress1(registerationDto.getAddress1());

						AddressType addressType = new AddressType();
						addressType.setAddressTypeId(1);
						addressType.setAddressTypeName("Personal");

						address.setAddressType(addressType);
						address.setBlock(registerationDto.getBlock());
						address.setCity(registerationDto.getCity());
						address.setDistrict(registerationDto.getDistrict());
						address.setLatitude(registerationDto.getLatitude());
						address.setLongitude(registerationDto.getLongitude());
						address.setPincode(registerationDto.getPinCode());
						address.setCreatedOn(CommonUtilities.currentDateTime());
						address.setStatus(true);
						userAddress.add(address);

						user.setUserAddresses(userAddress);

						if (COUNTRY.equals("INDIA")) {
							user.setAadhaarCard(registerationDto.getAadharNumber());
						}

						if (COUNTRY.equals("NEPAL")) {
							user.setAadhaarCard(registerationDto.getNepalCitizenshipNumber());
						}

						RoleMaster roleMaster = new RoleMaster();
						roleMaster.setRoleMasterId(1);
						user.setRoleMaster(roleMaster);

						user.setEmailId(registerationDto.getEmailId());
						user.setFirstName(registerationDto.getFirstName());
						user.setLastName(registerationDto.getLastName());
						user.setPassword(CommonUtilities.encrypt(registerationDto.getPassword()));
						user.setImeiNo(registerationDto.getImei());
						user.setMobileNo(registerationDto.getMobileNo());
						user.setReferenceCode(registerationDto.getReferenceCode());
						user.setCreatedOn(CommonUtilities.currentDateTime());
						user.setParentUserId(0);
						user.setStatus(true);

						if (registerationDto.getProfilePic() != null) {
							System.out.println(".........");
							String fileName = CommonUtilities.fetchTimeInMilliSeconds() + AWS_FILE_FORMAT;
							String bucketName = AWS_BUCKET_NAME;
							s3client.putObject(
									new PutObjectRequest(bucketName, fileName, CommonUtilities.convertBS64ImgToFile(
											registerationDto.getProfilePic(), registerationDto.getPath())));
							user.setProfilePic(AWS_DEFAULT_URL + bucketName + "/" + fileName);
						}

						user = gatewayDao.saveOrUpdateUser(user);

						userDto.setUserId(user.getUserId());
						System.out.println("....................");
						status.setStatus(1);
						status.setMessage(REGISTRATION_PROCESS_COMPLETED_MESSAGE);
					} else {
						User farmerInfo = userInfo.get(0);
						if (farmerInfo.getRoleMaster().getRoleMasterId() == 1) {
							status.setStatus(0);
							status.setMessage(registerationDto.getMobileNo() + USER_ALREADY_REGISTERED_AS_ME);
						} else {
							status.setStatus(0);
							status.setMessage(registerationDto.getMobileNo() + FARMER_ALREADY_REGISTERED);
						}
					}
				} else {
					status.setStatus(0);
					status.setMessage(INVALID_MOBILE_NO_MESSAGE);
				}
			} else {
				status.setStatus(0);
				status.setMessage(ENTER_MOBILE_NUMBER_MESSAGE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		userDto.setStatusDto(status);
		return userDto;
	}

	@Override
	public CountryDto getAllCountries() {
		CountryDto countryDto = new CountryDto();
		StatusDto status = new StatusDto();
		try {
			List<CountryMasterDto> countryMasterDtos = new ArrayList<CountryMasterDto>();
			List<CountryMaster> countries = gatewayDao.fetchAllCountries();
			if (!countries.isEmpty()) {
				for (CountryMaster country : countries) {
					CountryMasterDto cDto = new CountryMasterDto();
					cDto.setCountryMasterId(country.getCountryMasterId());
					cDto.setCountryName(country.getCountryName());
					countryMasterDtos.add(cDto);
				}
			}
			countryDto.setCountryMasterDto(countryMasterDtos);

			status.setStatus(1);
			status.setMessage(SUCCESSFULL_MESSAGE);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}

		countryDto.setStatus(status);

		return countryDto;
	}

	@Override
	public StateDto getSateByCountry(CountryMasterDto countryMasterDto) {
		StateDto stateDto = new StateDto();
		StatusDto status = new StatusDto();
		try {
			List<StateMasterDto> countryStateDto = new ArrayList<StateMasterDto>();
			List<StateMaster> states = gatewayDao.fetchAllStatesByCountryId(countryMasterDto.getCountryMasterId());
			if (!states.isEmpty()) {
				for (StateMaster state : states) {
					if (state.getStatus() == true) {
						StateMasterDto sDto = new StateMasterDto();
						sDto.setStateMasterId(state.getStateMasterId());
						sDto.setStateName(state.getStateName());
						countryStateDto.add(sDto);
					}
				}
			}

			countryStateDto.sort(Comparator.comparing(StateMasterDto::getStateName));

			stateDto.setStateMasterDto(countryStateDto);

			status.setStatus(1);
			status.setMessage(SUCCESSFULL_MESSAGE);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		stateDto.setStatus(status);
		return stateDto;
	}

	@Override
	public DistrictDto getDistrictByState(StateMasterDto stateMasterdto) {
		DistrictDto districtDto = new DistrictDto();
		StatusDto status = new StatusDto();
		try {
			List<DistrictMasterDto> districtMasterDto = new ArrayList<DistrictMasterDto>();
			List<DistrictMaster> districts = gatewayDao.fetchDistrictByStateId(stateMasterdto.getStateMasterId());
			System.out.println(districts.size());
			if (!districts.isEmpty()) {
				for (DistrictMaster district : districts) {
					if (district.getStatus() == true) {
						DistrictMasterDto dDto = new DistrictMasterDto();
						dDto.setDistrictMasterId(district.getDistrictMasterId());
						dDto.setDistrictName(district.getDistrictName());
						districtMasterDto.add(dDto);
					}
				}
			}

			districtMasterDto.sort(Comparator.comparing(DistrictMasterDto::getDistrictName));

			districtDto.setDistrictMasterDto(districtMasterDto);

			status.setStatus(1);
			status.setMessage(SUCCESSFULL_MESSAGE);
		} catch (Exception e) {
			e.printStackTrace();

			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}

		districtDto.setStatus(status);
		return districtDto;
	}

	@Override
	public StatusDto forgetPassword(RegistrationDto registerationDto) {
		StatusDto status = new StatusDto();
		try {
			if (!(registerationDto.getMobileNo() == null && registerationDto.getMobileNo().isEmpty())) {
				if (registerationDto.getMobileNo().length() == INDIAN_MOBILE_NO_LENGTH) {
					List<User> userInfoList = gatewayDao.fetchUserByMobileNo(registerationDto.getMobileNo());
					if (!userInfoList.isEmpty()) {
						User user = userInfoList.get(0);
						user.setPassword(CommonUtilities.encrypt(registerationDto.getPassword()));
						gatewayDao.saveOrUpdateUser(user);
						status.setStatus(1);
						status.setMessage(PASSWORD_CHANGED_SUCCESSFULLY);
					} else {
						status.setStatus(0);
						status.setMessage(registerationDto.getMobileNo() + " " + MOBILE_NO_NOT_REGISTERED);
					}
				} else {
					status.setStatus(0);
					status.setMessage(INVALID_MOBILE_NO_MESSAGE);
				}
			} else {
				status.setStatus(0);
				status.setMessage(ENTER_MOBILE_NUMBER_MESSAGE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		return status;
	}

	@Override
	public UserDto login(RegistrationDto registrationDto) {
		UserDto userDto = new UserDto();
		StatusDto status = new StatusDto();
		try {
			if (!(registrationDto.getMobileNo() == null && registrationDto.getMobileNo().isEmpty())) {
				if (registrationDto.getMobileNo().length() == INDIAN_MOBILE_NO_LENGTH) {
					List<User> userInfoList = gatewayDao.fetchUserByMobileNo(registrationDto.getMobileNo());
					if (!userInfoList.isEmpty()) {
						User user = userInfoList.get(0);
						if (user.getRoleMaster().getRoleMasterId() == 1) {
							if (user.getPassword().equals(CommonUtilities.encrypt(registrationDto.getPassword()))) {
								userDto.setUserId(user.getUserId());
								status.setStatus(1);
								status.setMessage(LOGIN_SUCCESSFUL);
							} else {
								status.setStatus(0);
								status.setMessage(LOGIN_FAILED);
							}
						} else {
							status.setStatus(0);
							status.setMessage(registrationDto.getMobileNo() + FARMER_ALREADY_REGISTERED);
						}
					} else {
						status.setStatus(0);
						status.setMessage(registrationDto.getMobileNo() + MOBILE_NO_NOT_REGISTERED);
					}
				} else {
					status.setStatus(0);
					status.setMessage(INVALID_MOBILE_NO_MESSAGE);
				}
			} else {
				status.setStatus(0);
				status.setMessage(ENTER_MOBILE_NUMBER_MESSAGE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		userDto.setStatusDto(status);
		return userDto;
	}

	@Override
	public RegistrationDto meInfo(RegistrationDto registrationDto) {
		RegistrationDto meInfo = new RegistrationDto();
		StatusDto status = new StatusDto();
		try {
			User meDetail = gatewayDao.fetchUserByUserId(registrationDto.getUserId()).get(0);
			if (meDetail != null) {

				if (COUNTRY.equals("INDIA")) {
					meInfo.setAadharNumber(meDetail.getAadhaarCard());
				} else {
					meInfo.setNepalCitizenshipNumber(meDetail.getAadhaarCard());
				}

				meInfo.setUserId(meDetail.getUserId());
				meInfo.setFirstName(meDetail.getFirstName());
				meInfo.setLastName(meDetail.getLastName());
				meInfo.setMobileNo(meDetail.getMobileNo());
				meInfo.setEmailId(meDetail.getEmailId());

				List<UserAddress> userAddress = new ArrayList<UserAddress>(meDetail.getUserAddresses());
				UserAddress uA = userAddress.get(0);
				meInfo.setAddress1(uA.getAddress1());
				meInfo.setBlock(uA.getBlock());
				meInfo.setCity(uA.getCity());
				meInfo.setDistrict(uA.getDistrict());
				DistrictMaster dM = gatewayDao.fetchDistrictByDistrictId(uA.getDistrict());
				meInfo.setDistrictName(dM.getDistrictName());
				meInfo.setPinCode(uA.getPincode());
				meInfo.setLatitude(uA.getLatitude());
				meInfo.setLongitude(uA.getLatitude());

				status.setStatus(1);
				status.setMessage(SUCCESSFULL_MESSAGE);

			} else {
				status.setStatus(0);
				status.setMessage(USER_NOT_REGISTERED);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		meInfo.setStatus(status);
		return meInfo;
	}

	@Override
	public RegistrationDto editInfo(RegistrationDto registrationDto) {
		RegistrationDto meInfo = new RegistrationDto();
		StatusDto status = new StatusDto();
		try {
			List<User> userList = gatewayDao.fetchUserByUserId(registrationDto.getUserId());
			if (!userList.isEmpty()) {
				User user = userList.get(0);

				if (user.getParentUserId() == 0) {

					Set<UserAddress> userAddressSet = new HashSet<UserAddress>();
					List<UserAddress> userAddress = new ArrayList<UserAddress>(user.getUserAddresses());
					UserAddress address = userAddress.get(0);
					address.setAddress1(registrationDto.getAddress1());

					AddressType addressType = new AddressType();
					addressType.setAddressTypeId(1);
					addressType.setAddressTypeName("Personal");

					address.setAddressType(addressType);
					address.setBlock(registrationDto.getBlock());
					address.setCity(registrationDto.getCity());
					address.setDistrict(registrationDto.getDistrict());
					address.setLatitude(registrationDto.getLatitude());
					address.setLongitude(registrationDto.getLongitude());
					address.setPincode(registrationDto.getPinCode());
					address.setUpdatedBy(registrationDto.getUserId());
					address.setUpdatedOn(CommonUtilities.currentDateTime());
					address.setStatus(true);

					userAddressSet.add(address);

					user.setUserAddresses(userAddressSet);

					if (COUNTRY.equals("INDIA")) {
						user.setAadhaarCard(registrationDto.getAadharNumber());
					}

					if (COUNTRY.equals("NEPAL")) {
						user.setAadhaarCard(registrationDto.getNepalCitizenshipNumber());
					}

					RoleMaster roleMaster = new RoleMaster();
					roleMaster.setRoleMasterId(1);
					user.setRoleMaster(roleMaster);

					user.setEmailId(registrationDto.getEmailId());
					user.setFirstName(registrationDto.getFirstName());
					user.setLastName(registrationDto.getLastName());
					user.setUpdatedBy(registrationDto.getUserId());
					user.setUpdatedOn(CommonUtilities.currentDateTime());
					user.setParentUserId(0);
					user.setStatus(true);

					user = gatewayDao.saveOrUpdateUser(user);

					status.setStatus(1);
					status.setMessage(PROFILE_EDITED_SUCCESSFULLY);
				} else {
					status.setStatus(0);
					status.setMessage(NOT_FARMER);
				}
			} else {
				status.setStatus(0);
				status.setMessage(USER_NOT_REGISTERED);
			}
		} catch (

		Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		meInfo.setStatus(status);
		return meInfo;
	}

}
