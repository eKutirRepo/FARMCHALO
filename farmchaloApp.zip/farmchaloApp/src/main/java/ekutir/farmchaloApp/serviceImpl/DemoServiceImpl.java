package ekutir.farmchaloApp.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ekutir.farmchaloApp.dao.DemoDao;
import ekutir.farmchaloApp.model.Demo;
import ekutir.farmchaloApp.service.DemoService;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:45:08 AM
 * 
 */
@Service
public class DemoServiceImpl implements DemoService{

	@Autowired
	DemoDao demoDao;

	@Override
	public void saveDemo(Demo demo) {
		demoDao.saveDemo(demo);
	}
}
