package ekutir.farmchaloApp.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ekutir.farmchaloApp.dao.FarmerDao;
import ekutir.farmchaloApp.dto.FarmerRegisterationDto;
import ekutir.farmchaloApp.dto.IrrigationTypeDto;
import ekutir.farmchaloApp.dto.LandAreaMasterUomDto;
import ekutir.farmchaloApp.dto.LandDetailsDto;
import ekutir.farmchaloApp.dto.LandDto;
import ekutir.farmchaloApp.dto.LandOwnershipDto;
import ekutir.farmchaloApp.dto.LandTypeMasterDto;
import ekutir.farmchaloApp.dto.MyFarmersDto;
import ekutir.farmchaloApp.dto.StatusDto;
import ekutir.farmchaloApp.model.AddressType;
import ekutir.farmchaloApp.model.CountryMaster;
import ekutir.farmchaloApp.model.DistrictMaster;
import ekutir.farmchaloApp.model.IrrigationType;
import ekutir.farmchaloApp.model.LandAreaMasterUom;
import ekutir.farmchaloApp.model.LandDetails;
import ekutir.farmchaloApp.model.LandOwnership;
import ekutir.farmchaloApp.model.LandTypeMaster;
import ekutir.farmchaloApp.model.RoleMaster;
import ekutir.farmchaloApp.model.StateMaster;
import ekutir.farmchaloApp.model.User;
import ekutir.farmchaloApp.model.UserAddress;
import ekutir.farmchaloApp.service.FarmerService;
import ekutir.utilities.CommonUtilities;

import static ekutir.farmchaloApp.configuration.AppConstants.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:45:13 AM
 * 
 */
@Service
public class FarmerServiceImpl implements FarmerService {

	@Autowired
	FarmerDao farmerDao;

	@Override
	public FarmerRegisterationDto farmerRegistration(FarmerRegisterationDto farmerRegistrationDto) {
		FarmerRegisterationDto farmerDto = new FarmerRegisterationDto();
		StatusDto status = new StatusDto();
		try {
			List<User> meInfoList = farmerDao.fetchUserByUserId(farmerRegistrationDto.getUserId());
			if (!meInfoList.isEmpty()) {
				User meInfo = meInfoList.get(0);
				System.out.println(meInfo.getRoleMaster().getRoleMasterId());
				if (meInfo.getRoleMaster().getRoleMasterId() == 1) {
					System.out.println(".....");
					if (farmerRegistrationDto.getMobileNo() != null) {
						if (farmerRegistrationDto.getMobileNo().length() == INDIAN_MOBILE_NO_LENGTH) {
							List<User> farmerInfoList = farmerDao
									.fetchUserByMobileNo(farmerRegistrationDto.getMobileNo());
							if (farmerInfoList.isEmpty()) {

								User user = new User();

								Set<UserAddress> userAddress = new HashSet<UserAddress>();
								UserAddress address = new UserAddress();
								address.setAddress1(farmerRegistrationDto.getAddress1());

								AddressType addressType = new AddressType();
								addressType.setAddressTypeId(1);
								addressType.setAddressTypeName("Personal");

								address.setAddressType(addressType);
								address.setBlock(farmerRegistrationDto.getBlock());
								address.setCity(farmerRegistrationDto.getCity());
								address.setDistrict(farmerRegistrationDto.getDistrict());
								address.setLatitude(farmerRegistrationDto.getLatitude());
								address.setLongitude(farmerRegistrationDto.getLongitude());
								address.setPincode(farmerRegistrationDto.getPinCode());
								address.setCreatedOn(CommonUtilities.currentDateTime());
								address.setStatus(true);
								userAddress.add(address);

								user.setUserAddresses(userAddress);

								if (COUNTRY.equals("INDIA")) {
									user.setAadhaarCard(farmerRegistrationDto.getAadharNumber());
								}

								if (COUNTRY.equals("NEPAL")) {
									user.setAadhaarCard(farmerRegistrationDto.getNepalCitizenshipNumber());
								}

								RoleMaster roleMaster = new RoleMaster();
								roleMaster.setRoleMasterId(2);
								roleMaster.setRoleName("Farmer");
								user.setRoleMaster(roleMaster);

								user.setFirstName(farmerRegistrationDto.getFirstName());
								user.setLastName(farmerRegistrationDto.getLastName());
								user.setParentUserId(farmerRegistrationDto.getUserId());
								user.setMobileNo(farmerRegistrationDto.getMobileNo());
								user.setCreatedOn(CommonUtilities.currentDateTime());
								user.setStatus(true);

								Set<LandDetails> landDetailsSet = new HashSet<LandDetails>();

								if (!farmerRegistrationDto.getLandDetailsDto().isEmpty()) {
									for (LandDetailsDto landDetailDto : farmerRegistrationDto.getLandDetailsDto()) {
										LandDetails landDetail = new LandDetails();

										IrrigationType irrigationType = new IrrigationType();
										irrigationType.setIrrigationTypeId(landDetailDto.getIrrigationTypeId());
										irrigationType.setIrrigationTypeName(IrrigationType
												.irrigationNameByIdEnum(landDetailDto.getIrrigationTypeId()));
										landDetail.setIrrigationType(irrigationType);

										LandAreaMasterUom landAreaMasterUom = new LandAreaMasterUom();
										landAreaMasterUom
												.setLandAreaMasterUomId(landDetailDto.getLandAreaMasterUomId());
										landDetail.setLandAreaMasterUom(landAreaMasterUom);

										LandOwnership landOwnership = new LandOwnership();
										landOwnership.setLandOwnershipId(landDetailDto.getLandOwnershipId());
										landDetail.setLandOwnership(landOwnership);

										LandTypeMaster landTypeMaster = new LandTypeMaster();
										landTypeMaster.setLandTypeMasterId(landDetailDto.getLandTypeMasterId());
										landDetail.setLandTypeMaster(landTypeMaster);

										landDetail.setLandArea(landDetailDto.getLandArea());
										landDetail.setLandLocation(landDetailDto.getLandLocation());
										landDetail.setLandLatitude(landDetailDto.getLandLatitude());
										landDetail.setLandLongitude(landDetailDto.getLandLongitude());
										landDetail.setStatus(true);
										landDetail.setCreatedBy(farmerRegistrationDto.getUserId());
										landDetail.setCreatedOn(CommonUtilities.currentDateTime());

										landDetailsSet.add(landDetail);

									}
								}
								user.setLandDetailses(landDetailsSet);

								user.setStatus(true);

								user = farmerDao.saveOrUpdateUser(user);

								farmerDto.setFarmerId(user.getUserId());
								System.out.println("....................");
								status.setStatus(1);
								status.setMessage(REGISTRATION_PROCESS_COMPLETED_MESSAGE);
							} else {
								User farmerInfo = farmerInfoList.get(0);
								if (farmerInfo.getRoleMaster().getRoleMasterId() == 1) {
									status.setStatus(0);
									status.setMessage(
											farmerRegistrationDto.getMobileNo() + USER_ALREADY_REGISTERED_AS_ME);
								} else {
									status.setStatus(0);
									status.setMessage(farmerRegistrationDto.getMobileNo() + FARMER_ALREADY_REGISTERED);
								}

							}
						} else {
							status.setStatus(0);
							status.setMessage(INVALID_MOBILE_NO_MESSAGE);
						}
					} else {
						status.setStatus(0);
						status.setMessage(ENTER_MOBILE_NUMBER_MESSAGE);
					}
				} else {
					status.setStatus(0);
					status.setMessage(meInfo.getMobileNo() + FARMER_ALREADY_REGISTERED);
				}
			} else {
				status.setStatus(0);
				status.setMessage(USER_NOT_REGISTERED);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		farmerDto.setStatus(status);
		return farmerDto;
	}

	@Override
	public LandDto getLandInfo(LandAreaMasterUomDto landAreaMasterUomDto) {
		LandDto landDto = new LandDto();
		StatusDto status = new StatusDto();
		try {
			List<IrrigationTypeDto> irrigationTypeDtoList = new ArrayList<IrrigationTypeDto>();
			List<IrrigationType> irrigationTypeList = farmerDao.fetchAllIrrigationTypes();

			List<LandAreaMasterUomDto> landAreaMasterUomDtoList = new ArrayList<LandAreaMasterUomDto>();
			List<LandAreaMasterUom> landAreaMasterUomList = farmerDao.fetchAllLandAreaMasterUoms();

			List<LandOwnershipDto> landOwnershipDtoList = new ArrayList<LandOwnershipDto>();
			List<LandOwnership> landOwnershipList = farmerDao.fetchAllLandOwnerships();

			List<LandTypeMasterDto> landTypeMasterDtoList = new ArrayList<LandTypeMasterDto>();
			List<LandTypeMaster> landTypeMasterList = farmerDao.fetchAllLandTypeMasters();

			if (!irrigationTypeList.isEmpty()) {
				for (IrrigationType iType : irrigationTypeList) {
					IrrigationTypeDto iDto = new IrrigationTypeDto();
					iDto.setIrrigationTypeId(iType.getIrrigationTypeId());
					iDto.setIrrigationTypeName(iType.getIrrigationTypeName());
					irrigationTypeDtoList.add(iDto);
				}
			}
			landDto.setIrrigationTypeList(irrigationTypeDtoList);

			if (!landAreaMasterUomList.isEmpty()) {
				System.out.println(landAreaMasterUomDto.getCountryMasterId() + "......");
				for (LandAreaMasterUom lOm : landAreaMasterUomList) {
					if (lOm.getCountryMaster().getCountryMasterId() == landAreaMasterUomDto.getCountryMasterId()) {
						System.out.println(lOm.getUom() + "......");
						LandAreaMasterUomDto lDto = new LandAreaMasterUomDto();
						lDto.setLandAreaMasterUomId(lOm.getLandAreaMasterUomId());
						lDto.setUom(lOm.getUom());
						landAreaMasterUomDtoList.add(lDto);
					}
				}
			}
			landDto.setLandAreaMasterUomList(landAreaMasterUomDtoList);

			if (!landOwnershipList.isEmpty()) {
				for (LandOwnership os : landOwnershipList) {
					LandOwnershipDto oDto = new LandOwnershipDto();
					oDto.setLandOwnershipId(os.getLandOwnershipId());
					oDto.setLandOwnershipName(os.getLandOwnershipName());
					landOwnershipDtoList.add(oDto);
				}
			}
			landDto.setLandOwnershipList(landOwnershipDtoList);

			if (!landTypeMasterList.isEmpty()) {
				for (LandTypeMaster tm : landTypeMasterList) {
					LandTypeMasterDto tDto = new LandTypeMasterDto();
					tDto.setLandTypeMasterId(tm.getLandTypeMasterId());
					tDto.setLandTypeName(tm.getLandTypeName());
					landTypeMasterDtoList.add(tDto);
				}
			}
			landDto.setLandTypeMasterList(landTypeMasterDtoList);

			status.setStatus(1);
			status.setMessage(SUCCESSFULL_MESSAGE);
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		landDto.setStatus(status);
		return landDto;
	}

	@Override
	public MyFarmersDto fetchMyFarmers(FarmerRegisterationDto farmerRegistrationDto) {
		MyFarmersDto farmerDto = new MyFarmersDto();
		StatusDto status = new StatusDto();
		try {
			if (!farmerDao.fetchUserByUserId(farmerRegistrationDto.getUserId()).isEmpty()) {

				List<User> myFarmersList = farmerDao.fetchFarmersByMeId(farmerRegistrationDto.getUserId());
				List<FarmerRegisterationDto> myFarmersListDto = new ArrayList<FarmerRegisterationDto>();
				System.out.println(myFarmersList.size() + ".........");

				if (!myFarmersList.isEmpty()) {
					for (User farmer : myFarmersList) {
						FarmerRegisterationDto fDto = new FarmerRegisterationDto();
						fDto.setFarmerId(farmer.getUserId());
						fDto.setMobileNo(farmer.getMobileNo());
						fDto.setFirstName(farmer.getFirstName() + " " + farmer.getLastName());
						fDto.setUserId(farmerRegistrationDto.getUserId());
						myFarmersListDto.add(fDto);
					}

					myFarmersListDto.sort(Comparator.comparing(FarmerRegisterationDto::getFirstName));
					farmerDto.setMyFarmers(myFarmersListDto);

					status.setStatus(1);
					status.setMessage(SUCCESSFULL_MESSAGE);
				} else {
					status.setStatus(0);
					status.setMessage(NO_FARMERS);
				}
			} else {
				status.setStatus(0);
				status.setMessage(USER_NOT_REGISTERED);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		farmerDto.setStatus(status);
		return farmerDto;
	}

	@Override
	public FarmerRegisterationDto fetchFarmerInfo(FarmerRegisterationDto farmerRegistrationDto) {
		FarmerRegisterationDto farmerInfoDto = new FarmerRegisterationDto();
		StatusDto status = new StatusDto();
		try {
			User farmerDetails = farmerDao.fetchUserByUserId(farmerRegistrationDto.getFarmerId()).get(0);
			if (farmerDetails != null) {

				if (COUNTRY.equals("INDIA")) {
					farmerInfoDto.setAadharNumber(farmerDetails.getAadhaarCard());
				} else {
					farmerInfoDto.setNepalCitizenshipNumber(farmerDetails.getAadhaarCard());
				}

				farmerInfoDto.setFarmerId(farmerDetails.getUserId());
				farmerInfoDto.setFirstName(farmerDetails.getFirstName());
				farmerInfoDto.setLastName(farmerDetails.getLastName());
				farmerInfoDto.setMobileNo(farmerDetails.getMobileNo());
				farmerInfoDto.setUserId(farmerDetails.getParentUserId());
				User meInfo = farmerDao.fetchUserByUserId(farmerDetails.getParentUserId()).get(0);
				farmerInfoDto.setUserName(meInfo.getFirstName() + " " + meInfo.getLastName());

				List<UserAddress> addressList = new ArrayList<UserAddress>(farmerDetails.getUserAddresses());
				UserAddress address = addressList.get(0);
				farmerInfoDto.setAddress1(address.getAddress1());
				farmerInfoDto.setBlock(address.getBlock());
				farmerInfoDto.setCity(address.getCity());
				farmerInfoDto.setDistrict(address.getDistrict());
				DistrictMaster district = farmerDao.fetchDistrictByDistrictId(address.getDistrict()).get(0);
				farmerInfoDto.setDistrictName(district.getDistrictName());
				StateMaster stateMaster = district.getStateMaster();
				farmerInfoDto.setStateName(stateMaster.getStateName());
				CountryMaster countryMaster = stateMaster.getCountryMaster();
				farmerInfoDto.setCountry(countryMaster.getCountryName());
				farmerInfoDto.setPinCode(address.getPincode());
				farmerInfoDto.setLatitude(address.getLatitude());
				farmerInfoDto.setLongitude(address.getLongitude());

				Set<LandDetails> landDetailList = farmerDetails.getLandDetailses();
				Set<LandDetailsDto> landDetailListDto = new HashSet<LandDetailsDto>();

				if (!landDetailList.isEmpty()) {
					for (LandDetails lD : landDetailList) {
						LandDetailsDto lDto = new LandDetailsDto();

						IrrigationType iT = lD.getIrrigationType();
						lDto.setIrrigationTypeId(iT.getIrrigationTypeId());
						lDto.setIrrigationTypeName(iT.getIrrigationTypeName());

						LandAreaMasterUom mU = lD.getLandAreaMasterUom();
						lDto.setLandAreaMasterUomId(mU.getLandAreaMasterUomId());
						lDto.setLandAreaMasterUomName(mU.getUom());

						LandTypeMaster tM = lD.getLandTypeMaster();
						lDto.setLandTypeMasterId(tM.getLandTypeMasterId());
						lDto.setLandTypeMasterName(tM.getLandTypeName());

						LandOwnership oS = lD.getLandOwnership();
						lDto.setLandOwnershipId(oS.getLandOwnershipId());
						lDto.setLandOwnershipName(oS.getLandOwnershipName());

						lDto.setLandArea(lD.getLandArea());
						lDto.setLandDetailsId(lD.getLandDetailsId());
						lDto.setLandLatitude(lD.getLandLatitude());
						lDto.setLandLongitude(lD.getLandLongitude());
						lDto.setLandLocation(lD.getLandLocation());
						lDto.setFarmerId(farmerDetails.getUserId());

						landDetailListDto.add(lDto);
					}
				}

				farmerInfoDto.setLandDetailsDto(landDetailListDto);

				status.setStatus(1);
				status.setMessage(SUCCESSFULL_MESSAGE);
			} else {
				status.setStatus(0);
				status.setMessage(FARMER_NOT_REGISTERED);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		farmerInfoDto.setStatus(status);
		return farmerInfoDto;
	}

	@Override
	public LandDetailsDto addFarmersLand(LandDetailsDto landDetailsDto) {
		LandDetailsDto landDto = new LandDetailsDto();
		StatusDto status = new StatusDto();
		try {
			User farmerInfo = farmerDao.fetchUserByUserId(landDetailsDto.getFarmerId()).get(0);
			if (farmerInfo != null) {

				Set<LandDetails> landDetailsSet = farmerInfo.getLandDetailses();

				LandDetails newLand = new LandDetails();

				IrrigationType irrigationType = new IrrigationType();
				irrigationType.setIrrigationTypeId(landDetailsDto.getIrrigationTypeId());
				irrigationType.setIrrigationTypeName(
						IrrigationType.irrigationNameByIdEnum(landDetailsDto.getIrrigationTypeId()));
				newLand.setIrrigationType(irrigationType);

				LandAreaMasterUom landAreaMasterUom = new LandAreaMasterUom();
				landAreaMasterUom.setLandAreaMasterUomId(landDetailsDto.getLandAreaMasterUomId());
				newLand.setLandAreaMasterUom(landAreaMasterUom);

				LandOwnership landOwnership = new LandOwnership();
				landOwnership.setLandOwnershipId(landDetailsDto.getLandOwnershipId());
				newLand.setLandOwnership(landOwnership);

				LandTypeMaster landTypeMaster = new LandTypeMaster();
				landTypeMaster.setLandTypeMasterId(landDetailsDto.getLandTypeMasterId());
				newLand.setLandTypeMaster(landTypeMaster);

				newLand.setLandArea(landDetailsDto.getLandArea());
				newLand.setLandLocation(landDetailsDto.getLandLocation());
				newLand.setLandLatitude(landDetailsDto.getLandLatitude());
				newLand.setLandLongitude(landDetailsDto.getLandLongitude());
				newLand.setStatus(true);
				newLand.setCreatedBy(farmerInfo.getParentUserId());
				newLand.setCreatedOn(CommonUtilities.currentDateTime());

				landDetailsSet.add(newLand);

				farmerInfo.setLandDetailses(landDetailsSet);

				farmerInfo = farmerDao.saveOrUpdateUser(farmerInfo);

				status.setStatus(1);
				status.setMessage(LAND_ADDED_SUCCESSFULLY);

			} else {
				status.setStatus(0);
				status.setMessage(FARMER_NOT_REGISTERED);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		landDto.setStatusDto(status);
		return landDto;
	}

	@Override
	public FarmerRegisterationDto editFarmerInfo(FarmerRegisterationDto farmerRegistrationDto) {
		FarmerRegisterationDto farmerDto = new FarmerRegisterationDto();
		StatusDto status = new StatusDto();
		try {
			List<User> userList = farmerDao.fetchUserByUserId(farmerRegistrationDto.getFarmerId());
			if (!userList.isEmpty()) {

				User user = userList.get(0);
				if (user.getParentUserId() != 0) {

					Set<UserAddress> userAddressSet = new HashSet<UserAddress>();
					List<UserAddress> userAddress = new ArrayList<UserAddress>(user.getUserAddresses());
					UserAddress address = userAddress.get(0);
					address.setAddress1(farmerRegistrationDto.getAddress1());

					AddressType addressType = new AddressType();
					addressType.setAddressTypeId(1);
					addressType.setAddressTypeName("Personal");

					address.setAddressType(addressType);
					address.setBlock(farmerRegistrationDto.getBlock());
					address.setCity(farmerRegistrationDto.getCity());
					address.setDistrict(farmerRegistrationDto.getDistrict());
					address.setLatitude(farmerRegistrationDto.getLatitude());
					address.setLongitude(farmerRegistrationDto.getLongitude());
					address.setPincode(farmerRegistrationDto.getPinCode());
					address.setUpdatedBy(user.getParentUserId());
					address.setUpdatedOn(CommonUtilities.currentDateTime());
					address.setStatus(true);

					userAddressSet.add(address);

					user.setUserAddresses(userAddressSet);

					if (COUNTRY.equals("INDIA")) {
						user.setAadhaarCard(farmerRegistrationDto.getAadharNumber());
					}

					if (COUNTRY.equals("NEPAL")) {
						user.setAadhaarCard(farmerRegistrationDto.getNepalCitizenshipNumber());
					}

					RoleMaster roleMaster = new RoleMaster();
					roleMaster.setRoleMasterId(2);
					roleMaster.setRoleName("Farmer");
					user.setRoleMaster(roleMaster);

					user.setFirstName(farmerRegistrationDto.getFirstName());
					user.setLastName(farmerRegistrationDto.getLastName());
					user.setUpdatedBy(farmerRegistrationDto.getUserId());
					user.setUpdatedOn(CommonUtilities.currentDateTime());

					user = farmerDao.saveOrUpdateUser(user);

					farmerDto.setFarmerId(user.getUserId());

					System.out.println("....................");
					status.setStatus(1);
					status.setMessage(FARMER_EDITED_SUCCESSFULLY);
				} else {
					status.setStatus(0);
					status.setMessage(NOT_ME);
				}
			} else {
				status.setStatus(0);
				status.setMessage(FARMER_NOT_REGISTERED);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		farmerDto.setStatus(status);
		return farmerDto;
	}

	@Override
	public LandDetailsDto editFarmerLand(LandDetailsDto landDetailsDto) {
		LandDetailsDto landDto = new LandDetailsDto();
		StatusDto status = new StatusDto();
		try {
			User farmerInfo = farmerDao.fetchUserByUserId(landDetailsDto.getFarmerId()).get(0);
			if (farmerInfo != null) {

				Set<LandDetails> landDetailsSetDto = new HashSet<LandDetails>();
				Set<LandDetails> landDetailsSet = farmerInfo.getLandDetailses();

				if (!landDetailsSet.isEmpty()) {
					for (LandDetails newLand : landDetailsSet) {

						if (newLand.getLandDetailsId() == landDetailsDto.getLandDetailsId()) {

							IrrigationType irrigationType = new IrrigationType();
							irrigationType.setIrrigationTypeId(landDetailsDto.getIrrigationTypeId());
							irrigationType.setIrrigationTypeName(
									IrrigationType.irrigationNameByIdEnum(landDetailsDto.getIrrigationTypeId()));
							newLand.setIrrigationType(irrigationType);

							LandAreaMasterUom landAreaMasterUom = new LandAreaMasterUom();
							landAreaMasterUom.setLandAreaMasterUomId(landDetailsDto.getLandAreaMasterUomId());
							newLand.setLandAreaMasterUom(landAreaMasterUom);

							LandOwnership landOwnership = new LandOwnership();
							landOwnership.setLandOwnershipId(landDetailsDto.getLandOwnershipId());
							newLand.setLandOwnership(landOwnership);

							LandTypeMaster landTypeMaster = new LandTypeMaster();
							landTypeMaster.setLandTypeMasterId(landDetailsDto.getLandTypeMasterId());
							newLand.setLandTypeMaster(landTypeMaster);

							newLand.setLandArea(landDetailsDto.getLandArea());
							newLand.setLandLocation(landDetailsDto.getLandLocation());
							newLand.setLandLatitude(landDetailsDto.getLandLatitude());
							newLand.setLandLongitude(landDetailsDto.getLandLongitude());
							newLand.setStatus(true);
							newLand.setUpdatedBy(farmerInfo.getParentUserId());
							newLand.setUpdatedOn(CommonUtilities.currentDateTime());
						}

						landDetailsSetDto.add(newLand);

						farmerInfo.setLandDetailses(landDetailsSetDto);

						farmerInfo = farmerDao.saveOrUpdateUser(farmerInfo);

						status.setStatus(1);
						status.setMessage(LAND_EDITED_SUCCESSFULLY);

					}
				} else {
					status.setStatus(0);
				}

			} else {
				status.setStatus(0);
				status.setMessage(FARMER_NOT_REGISTERED);
			}
		} catch (Exception e) {
			e.printStackTrace();
			status.setStatus(0);
			status.setMessage(ERROR_MESSAGE);
		}
		landDto.setStatusDto(status);
		return landDto;
	}
}
