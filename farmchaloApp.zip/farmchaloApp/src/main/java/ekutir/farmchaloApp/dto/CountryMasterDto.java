package ekutir.farmchaloApp.dto;
// Generated Jul 26, 2018 4:00:01 PM by Hibernate Tools 4.3.1


import java.util.HashSet;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:41:05 AM
 * 
 */
@SuppressWarnings("serial")
public class CountryMasterDto  implements java.io.Serializable {


     private Integer countryMasterId;
     private String countryName;
     private Boolean status;
     private Set<StateMasterDto> stateMasters = new HashSet<StateMasterDto>(0);

    public CountryMasterDto() {
    }

	
    public CountryMasterDto(String countryName) {
        this.countryName = countryName;
    }
    public CountryMasterDto(String countryName, Boolean status, Set<StateMasterDto> stateMasters) {
       this.countryName = countryName;
       this.status = status;
       this.stateMasters = stateMasters;
    }
   
    public Integer getCountryMasterId() {
        return this.countryMasterId;
    }
    
    public void setCountryMasterId(Integer countryMasterId) {
        this.countryMasterId = countryMasterId;
    }
    public String getCountryName() {
        return this.countryName;
    }
    
    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
    public Boolean getStatus() {
        return this.status;
    }
    
    public void setStatus(Boolean status) {
        this.status = status;
    }
    public Set<StateMasterDto> getStateMasters() {
        return this.stateMasters;
    }
    
    public void setStateMasters(Set<StateMasterDto> stateMasters) {
        this.stateMasters = stateMasters;
    }




}


