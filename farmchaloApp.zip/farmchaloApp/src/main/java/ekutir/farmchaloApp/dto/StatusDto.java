package ekutir.farmchaloApp.dto;

import java.io.Serializable;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:08 AM
 * 
 */
public class StatusDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private int statusCode;
	private int status;
	private String statusMessage;
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusMessage() {
		return this.statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

}
