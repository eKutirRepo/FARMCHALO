package ekutir.farmchaloApp.dto;
// Generated Jul 26, 2018 4:00:01 PM by Hibernate Tools 4.3.1

import java.util.Date;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:42:40 AM
 * 
 */
public class PhoneXOtpDto implements java.io.Serializable {

	private Integer phoneXOtpId;
	private String mobileNo;
	private int otp;
	private Date createdOn;
	private Integer createdBy;
	private Date updatedOn;
	private String updatesBy;
	private StatusDto status;

	public PhoneXOtpDto() {
	}

	public PhoneXOtpDto(String mobileNo, int otp, Date createdOn) {
		this.mobileNo = mobileNo;
		this.otp = otp;
		this.createdOn = createdOn;
	}

	public PhoneXOtpDto(String mobileNo, int otp, Date createdOn, Integer createdBy, Date updatedOn, String updatesBy) {
		this.mobileNo = mobileNo;
		this.otp = otp;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.updatedOn = updatedOn;
		this.updatesBy = updatesBy;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public Integer getPhoneXOtpId() {
		return this.phoneXOtpId;
	}

	public void setPhoneXOtpId(Integer phoneXOtpId) {
		this.phoneXOtpId = phoneXOtpId;
	}

	public String getMobileNo() {
		return this.mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getOtp() {
		return this.otp;
	}

	public void setOtp(int otp) {
		this.otp = otp;
	}

	public Date getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Integer getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getUpdatesBy() {
		return this.updatesBy;
	}

	public void setUpdatesBy(String updatesBy) {
		this.updatesBy = updatesBy;
	}

}
