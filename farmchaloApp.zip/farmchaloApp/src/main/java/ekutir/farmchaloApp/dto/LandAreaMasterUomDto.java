package ekutir.farmchaloApp.dto;
// Generated Jul 28, 2018 3:03:46 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:41:45 AM
 * 
 */
@SuppressWarnings("serial")
public class LandAreaMasterUomDto implements java.io.Serializable {

	private Integer landAreaMasterUomId;
	private String uom;
	private Boolean status;
	private Set landDetailses = new HashSet(0);
	private Integer countryMasterId;

	public LandAreaMasterUomDto() {
	}

	public LandAreaMasterUomDto(String uom) {
		this.uom = uom;
	}

	public LandAreaMasterUomDto(String uom, Boolean status, Set landDetailses) {
		this.uom = uom;
		this.status = status;
		this.landDetailses = landDetailses;
	}

	public Integer getLandAreaMasterUomId() {
		return this.landAreaMasterUomId;
	}

	public void setLandAreaMasterUomId(Integer landAreaMasterUomId) {
		this.landAreaMasterUomId = landAreaMasterUomId;
	}

	public String getUom() {
		return this.uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Set getLandDetailses() {
		return this.landDetailses;
	}

	public void setLandDetailses(Set landDetailses) {
		this.landDetailses = landDetailses;
	}

	public Integer getCountryMasterId() {
		return countryMasterId;
	}

	public void setCountryMasterId(Integer countryMasterId) {
		this.countryMasterId = countryMasterId;
	}

}
