package ekutir.farmchaloApp.dto;
// Generated Jul 26, 2018 4:00:01 PM by Hibernate Tools 4.3.1


import java.util.HashSet;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:40:52 AM
 * 
 */
@SuppressWarnings("serial")
public class AddressTypeDto  implements java.io.Serializable {


     private Integer addressTypeId;
     private String addressTypeName;
     private Boolean status;
     private Set<UserAddressDto> userAddresses = new HashSet<UserAddressDto>(0);

    public AddressTypeDto() {
    }

	
    public AddressTypeDto(String addressTypeName) {
        this.addressTypeName = addressTypeName;
    }
    public AddressTypeDto(String addressTypeName, Boolean status, Set<UserAddressDto> userAddresses) {
       this.addressTypeName = addressTypeName;
       this.status = status;
       this.userAddresses = userAddresses;
    }
   
    public Integer getAddressTypeId() {
        return this.addressTypeId;
    }
    
    public void setAddressTypeId(Integer addressTypeId) {
        this.addressTypeId = addressTypeId;
    }
    public String getAddressTypeName() {
        return this.addressTypeName;
    }
    
    public void setAddressTypeName(String addressTypeName) {
        this.addressTypeName = addressTypeName;
    }
    public Boolean getStatus() {
        return this.status;
    }
    
    public void setStatus(Boolean status) {
        this.status = status;
    }
    public Set<UserAddressDto> getUserAddresses() {
        return this.userAddresses;
    }
    
    public void setUserAddresses(Set<UserAddressDto> userAddresses) {
        this.userAddresses = userAddresses;
    }




}


