package ekutir.farmchaloApp.dto;

import java.util.List;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:42:10 AM
 * 
 */
public class LandDto {

	private List<IrrigationTypeDto> irrigationTypeList;
	private List<LandAreaMasterUomDto> landAreaMasterUomList;
	private List<LandOwnershipDto> landOwnershipList;
	private List<LandTypeMasterDto> landTypeMasterList;
	private StatusDto status;

	public LandDto() {
		super();
	}

	public LandDto(List<IrrigationTypeDto> irrigationTypeList, List<LandAreaMasterUomDto> landAreaMasterUomList,
			List<LandOwnershipDto> landOwnershipList, List<LandTypeMasterDto> landTypeMasterList, StatusDto status) {
		super();
		this.irrigationTypeList = irrigationTypeList;
		this.landAreaMasterUomList = landAreaMasterUomList;
		this.landOwnershipList = landOwnershipList;
		this.landTypeMasterList = landTypeMasterList;
		this.status = status;
	}

	public List<IrrigationTypeDto> getIrrigationTypeList() {
		return irrigationTypeList;
	}

	public void setIrrigationTypeList(List<IrrigationTypeDto> irrigationTypeList) {
		this.irrigationTypeList = irrigationTypeList;
	}

	public List<LandAreaMasterUomDto> getLandAreaMasterUomList() {
		return landAreaMasterUomList;
	}

	public void setLandAreaMasterUomList(List<LandAreaMasterUomDto> landAreaMasterUomList) {
		this.landAreaMasterUomList = landAreaMasterUomList;
	}

	public List<LandOwnershipDto> getLandOwnershipList() {
		return landOwnershipList;
	}

	public void setLandOwnershipList(List<LandOwnershipDto> landOwnershipList) {
		this.landOwnershipList = landOwnershipList;
	}

	public List<LandTypeMasterDto> getLandTypeMasterList() {
		return landTypeMasterList;
	}

	public void setLandTypeMasterList(List<LandTypeMasterDto> landTypeMasterList) {
		this.landTypeMasterList = landTypeMasterList;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}
