package ekutir.farmchaloApp.dto;
// Generated Jul 26, 2018 4:00:01 PM by Hibernate Tools 4.3.1

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import ekutir.farmchaloApp.model.UserAddress;


/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:17 AM
 * 
 */
@SuppressWarnings("serial")
public class UserDto implements java.io.Serializable {

	private Integer userId;
	private String mobileNo;
	private String firstName;
	private String lastName;
	private String emailId;
	private String businessName;
	private String aadhaarCard;
	private String nepalCitizenshipNumber;
	private String imeiNo;
	private Date createdOn;
	private int createdBy;
	private Date updatedOn;
	private Integer updatedBy;
	private Boolean status;
	private Set<UserAddress> userAddresses = new HashSet<UserAddress>(0);
	private StatusDto statusDto;

	public UserDto() {
	}

	public UserDto(String mobileNo, String firstName, String lastName, Date createdOn, int createdBy) {
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
	}

	public UserDto(String mobileNo, String firstName, String lastName, String emailId, String businessName,
			String aadhaarCard, String imeiNo, Date createdOn, int createdBy, Date updatedOn, Integer updatedBy,
			Boolean status, Set<UserAddress> userAddresses) {
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.businessName = businessName;
		this.aadhaarCard = aadhaarCard;
		this.imeiNo = imeiNo;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.updatedOn = updatedOn;
		this.updatedBy = updatedBy;
		this.status = status;
		this.userAddresses = userAddresses;
	}

	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getMobileNo() {
		return this.mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getBusinessName() {
		return this.businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getAadhaarCard() {
		return this.aadhaarCard;
	}

	public void setAadhaarCard(String aadhaarCard) {
		this.aadhaarCard = aadhaarCard;
	}

	public String getImeiNo() {
		return this.imeiNo;
	}

	public void setImeiNo(String imeiNo) {
		this.imeiNo = imeiNo;
	}

	public Date getCreatedOn() {
		return this.createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public int getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedOn() {
		return this.updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Integer getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Boolean getStatus() {
		return this.status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Set<UserAddress> getUserAddresses() {
		return this.userAddresses;
	}

	public void setUserAddresses(Set<UserAddress> userAddresses) {
		this.userAddresses = userAddresses;
	}

	public String getNepalCitizenshipNumber() {
		return nepalCitizenshipNumber;
	}

	public void setNepalCitizenshipNumber(String nepalCitizenshipNumber) {
		this.nepalCitizenshipNumber = nepalCitizenshipNumber;
	}

	public StatusDto getStatusDto() {
		return statusDto;
	}

	public void setStatusDto(StatusDto statusDto) {
		this.statusDto = statusDto;
	}
	
}
