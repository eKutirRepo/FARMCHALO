package ekutir.farmchaloApp.dto;

import java.util.List;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:42:57 AM
 * 
 */
public class StateDto {

	private List<StateMasterDto> stateMasterDto;
	private StatusDto status;

	public List<StateMasterDto> getStateMasterDto() {
		return stateMasterDto;
	}

	public void setStateMasterDto(List<StateMasterDto> stateMasterDto) {
		this.stateMasterDto = stateMasterDto;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}
