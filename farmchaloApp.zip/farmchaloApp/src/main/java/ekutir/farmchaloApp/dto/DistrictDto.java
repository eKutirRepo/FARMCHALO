package ekutir.farmchaloApp.dto;

import java.util.List;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:41:13 AM
 * 
 */
public class DistrictDto {

	List<DistrictMasterDto> districtMasterDto;
	StatusDto status;

	public List<DistrictMasterDto> getDistrictMasterDto() {
		return districtMasterDto;
	}

	public void setDistrictMasterDto(List<DistrictMasterDto> districtMasterDto) {
		this.districtMasterDto = districtMasterDto;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}
