package ekutir.farmchaloApp.dto;
// Generated Jul 26, 2018 4:00:01 PM by Hibernate Tools 4.3.1


/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:41:19 AM
 * 
 */
@SuppressWarnings("serial")
public class DistrictMasterDto  implements java.io.Serializable {


     private Integer districtMasterId;
     private StateMasterDto stateMaster;
     private String districtName;
     private Boolean status;

    public DistrictMasterDto() {
    }

	
    public DistrictMasterDto(StateMasterDto stateMaster, String districtName) {
        this.stateMaster = stateMaster;
        this.districtName = districtName;
    }
    public DistrictMasterDto(StateMasterDto stateMaster, String districtName, Boolean status) {
       this.stateMaster = stateMaster;
       this.districtName = districtName;
       this.status = status;
    }
   
    public Integer getDistrictMasterId() {
        return this.districtMasterId;
    }
    
    public void setDistrictMasterId(Integer districtMasterId) {
        this.districtMasterId = districtMasterId;
    }
    public StateMasterDto getStateMaster() {
        return this.stateMaster;
    }
    
    public void setStateMaster(StateMasterDto stateMaster) {
        this.stateMaster = stateMaster;
    }
    public String getDistrictName() {
        return this.districtName;
    }
    
    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }
    public Boolean getStatus() {
        return this.status;
    }
    
    public void setStatus(Boolean status) {
        this.status = status;
    }




}


