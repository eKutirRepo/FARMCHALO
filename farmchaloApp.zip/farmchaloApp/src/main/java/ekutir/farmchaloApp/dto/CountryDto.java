package ekutir.farmchaloApp.dto;

import java.util.List;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:40:59 AM
 * 
 */
public class CountryDto {
	private List<CountryMasterDto> countryMasterDto;

	private StatusDto status;

	public List<CountryMasterDto> getCountryMasterDto() {
		return countryMasterDto;
	}

	public void setCountryMasterDto(List<CountryMasterDto> countryMasterDto) {
		this.countryMasterDto = countryMasterDto;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}
