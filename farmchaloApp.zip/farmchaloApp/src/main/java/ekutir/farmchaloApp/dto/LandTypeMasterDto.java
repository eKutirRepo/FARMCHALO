package ekutir.farmchaloApp.dto;
// Generated Jul 28, 2018 3:03:46 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:42:21 AM
 * 
 */
public class LandTypeMasterDto implements java.io.Serializable {

	private Integer landTypeMasterId;
	private String landTypeName;
	private Boolean status;
	private Set landDetailses = new HashSet(0);

	public LandTypeMasterDto(Integer landTypeMasterId, String landTypeName, Boolean status, Set landDetailses) {
		super();
		this.landTypeMasterId = landTypeMasterId;
		this.landTypeName = landTypeName;
		this.status = status;
		this.landDetailses = landDetailses;
	}

	public LandTypeMasterDto() {
		super();
	}

	public Integer getLandTypeMasterId() {
		return landTypeMasterId;
	}

	public void setLandTypeMasterId(Integer landTypeMasterId) {
		this.landTypeMasterId = landTypeMasterId;
	}

	public String getLandTypeName() {
		return landTypeName;
	}

	public void setLandTypeName(String landTypeName) {
		this.landTypeName = landTypeName;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Set getLandDetailses() {
		return landDetailses;
	}

	public void setLandDetailses(Set landDetailses) {
		this.landDetailses = landDetailses;
	}

}
