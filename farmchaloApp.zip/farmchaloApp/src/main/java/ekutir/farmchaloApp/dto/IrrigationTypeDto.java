package ekutir.farmchaloApp.dto;
// Generated Jul 28, 2018 3:03:46 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:41:52 AM
 * 
 */
@SuppressWarnings("serial")
public class IrrigationTypeDto implements java.io.Serializable {

	private int irrigationTypeId;
	private String irrigationTypeName;
	private Integer status;
	private Set<LandDetailsDto> landDetailses = new HashSet<LandDetailsDto>(0);

	public IrrigationTypeDto() {
		super();
	}

	public IrrigationTypeDto(int irrigationTypeId, String irrigationTypeName, Integer status,
			Set<LandDetailsDto> landDetailses) {
		super();
		this.irrigationTypeId = irrigationTypeId;
		this.irrigationTypeName = irrigationTypeName;
		this.status = status;
		this.landDetailses = landDetailses;
	}

	public int getIrrigationTypeId() {
		return irrigationTypeId;
	}

	public void setIrrigationTypeId(int irrigationTypeId) {
		this.irrigationTypeId = irrigationTypeId;
	}

	public String getIrrigationTypeName() {
		return irrigationTypeName;
	}

	public void setIrrigationTypeName(String irrigationTypeName) {
		this.irrigationTypeName = irrigationTypeName;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Set<LandDetailsDto> getLandDetailses() {
		return landDetailses;
	}

	public void setLandDetailses(Set<LandDetailsDto> landDetailses) {
		this.landDetailses = landDetailses;
	}

}
