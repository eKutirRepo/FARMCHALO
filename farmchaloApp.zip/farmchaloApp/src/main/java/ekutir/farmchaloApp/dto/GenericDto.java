package ekutir.farmchaloApp.dto;

import java.util.List;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:41:36 AM
 * 
 */
public class GenericDto {

	private List<Object> genericList;
	private StatusDto status;

	public List<Object> getGenericList() {
		return genericList;
	}

	public void setGenericList(List<Object> genericList) {
		this.genericList = genericList;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}
