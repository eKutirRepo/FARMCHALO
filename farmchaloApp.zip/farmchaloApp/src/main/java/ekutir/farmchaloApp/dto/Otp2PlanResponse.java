package ekutir.farmchaloApp.dto;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:42:35 AM
 * 
 */
public class Otp2PlanResponse {
	private String status;
	private String details;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

}
