package ekutir.farmchaloApp.dto;
// Generated Jul 28, 2018 3:03:46 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:42:51 AM
 * 
 */
@SuppressWarnings("serial")
public class RoleMasterDto implements java.io.Serializable {

	private Integer roleMasterId;
	private String roleName;
	private Boolean status;
	@SuppressWarnings("rawtypes")
	private Set users = new HashSet(0);

	public RoleMasterDto() {
		super();
	}

	public RoleMasterDto(Integer roleMasterId, String roleName, Boolean status, Set users) {
		super();
		this.roleMasterId = roleMasterId;
		this.roleName = roleName;
		this.status = status;
		this.users = users;
	}

	public Integer getRoleMasterId() {
		return roleMasterId;
	}

	public void setRoleMasterId(Integer roleMasterId) {
		this.roleMasterId = roleMasterId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Set getUsers() {
		return users;
	}

	public void setUsers(Set users) {
		this.users = users;
	}

}
