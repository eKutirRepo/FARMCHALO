package ekutir.farmchaloApp.dto;
// Generated Jul 26, 2018 4:00:01 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:02 AM
 * 
 */
@SuppressWarnings("serial")
public class StateMasterDto implements java.io.Serializable {

	private Integer stateMasterId;
	private int countryMasterId;
	private String stateName;
	private Boolean status;
	private Set<DistrictMasterDto> districtMasters = new HashSet<DistrictMasterDto>(0);

	public StateMasterDto() {
	}

	public Integer getStateMasterId() {
		return stateMasterId;
	}

	public void setStateMasterId(Integer stateMasterId) {
		this.stateMasterId = stateMasterId;
	}

	public int getCountryMasterId() {
		return countryMasterId;
	}

	public void setCountryMasterId(int countryMasterId) {
		this.countryMasterId = countryMasterId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Set<DistrictMasterDto> getDistrictMasters() {
		return districtMasters;
	}

	public void setDistrictMasters(Set<DistrictMasterDto> districtMasters) {
		this.districtMasters = districtMasters;
	}

	public StateMasterDto(Integer stateMasterId, int countryMasterId, String stateName, Boolean status,
			Set<DistrictMasterDto> districtMasters) {
		super();
		this.stateMasterId = stateMasterId;
		this.countryMasterId = countryMasterId;
		this.stateName = stateName;
		this.status = status;
		this.districtMasters = districtMasters;
	}

}
