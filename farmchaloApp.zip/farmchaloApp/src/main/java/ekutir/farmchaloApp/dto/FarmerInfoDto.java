package ekutir.farmchaloApp.dto;

import ekutir.farmchaloApp.model.User;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:41:27 AM
 * 
 */
public class FarmerInfoDto {

	private User farmerDetails;
	private StatusDto status;

	public FarmerInfoDto() {
		super();
	}

	public FarmerInfoDto(User farmerDetails, StatusDto status) {
		super();
		this.farmerDetails = farmerDetails;
		this.status = status;
	}

	public User getFarmerDetails() {
		return farmerDetails;
	}

	public void setFarmerDetails(User farmerDetails) {
		this.farmerDetails = farmerDetails;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}
