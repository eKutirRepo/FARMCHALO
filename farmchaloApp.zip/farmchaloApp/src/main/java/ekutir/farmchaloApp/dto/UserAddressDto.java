package ekutir.farmchaloApp.dto;
// Generated Jul 26, 2018 4:00:01 PM by Hibernate Tools 4.3.1


import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:43:13 AM
 * 
 */
@SuppressWarnings("serial")
public class UserAddressDto  implements java.io.Serializable {


     private Integer userAddressId;
     private AddressTypeDto addressType;
     private UserDto user;
     private String address1;
     private String block;
     private String city;
     private int district;
     private int pincode;
     private Date createdOn;
     private int createdBy;
     private Date updatedOn;
     private Integer updatedBy;
     private Boolean status;
     private BigDecimal latitude;
     private BigDecimal longitude;

    public UserAddressDto() {
    }

	
    public UserAddressDto(AddressTypeDto addressType, UserDto user, String address1, String block, int district, int pincode, Date createdOn, int createdBy) {
        this.addressType = addressType;
        this.user = user;
        this.address1 = address1;
        this.block = block;
        this.district = district;
        this.pincode = pincode;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
    }
    public UserAddressDto(AddressTypeDto addressType, UserDto user, String address1, String block, String city, int district, int pincode, Date createdOn, int createdBy, Date updatedOn, Integer updatedBy, Boolean status, BigDecimal latitude, BigDecimal longitude) {
       this.addressType = addressType;
       this.user = user;
       this.address1 = address1;
       this.block = block;
       this.city = city;
       this.district = district;
       this.pincode = pincode;
       this.createdOn = createdOn;
       this.createdBy = createdBy;
       this.updatedOn = updatedOn;
       this.updatedBy = updatedBy;
       this.status = status;
       this.latitude = latitude;
       this.longitude = longitude;
    }
   
    public Integer getUserAddressId() {
        return this.userAddressId;
    }
    
    public void setUserAddressId(Integer userAddressId) {
        this.userAddressId = userAddressId;
    }
    public AddressTypeDto getAddressType() {
        return this.addressType;
    }
    
    public void setAddressType(AddressTypeDto addressType) {
        this.addressType = addressType;
    }
    public UserDto getUser() {
        return this.user;
    }
    
    public void setUser(UserDto user) {
        this.user = user;
    }
    public String getAddress1() {
        return this.address1;
    }
    
    public void setAddress1(String address1) {
        this.address1 = address1;
    }
    public String getBlock() {
        return this.block;
    }
    
    public void setBlock(String block) {
        this.block = block;
    }
    public String getCity() {
        return this.city;
    }
    
    public void setCity(String city) {
        this.city = city;
    }
    public int getDistrict() {
        return this.district;
    }
    
    public void setDistrict(int district) {
        this.district = district;
    }
    public int getPincode() {
        return this.pincode;
    }
    
    public void setPincode(int pincode) {
        this.pincode = pincode;
    }
    public Date getCreatedOn() {
        return this.createdOn;
    }
    
    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }
    public int getCreatedBy() {
        return this.createdBy;
    }
    
    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }
    public Date getUpdatedOn() {
        return this.updatedOn;
    }
    
    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }
    public Integer getUpdatedBy() {
        return this.updatedBy;
    }
    
    public void setUpdatedBy(Integer updatedBy) {
        this.updatedBy = updatedBy;
    }
    public Boolean getStatus() {
        return this.status;
    }
    
    public void setStatus(Boolean status) {
        this.status = status;
    }
    public BigDecimal getLatitude() {
        return this.latitude;
    }
    
    public void setLatitude(BigDecimal latitude) {
        this.latitude = latitude;
    }
    public BigDecimal getLongitude() {
        return this.longitude;
    }
    
    public void setLongitude(BigDecimal longitude) {
        this.longitude = longitude;
    }




}


