package ekutir.farmchaloApp.dto;
// Generated Jul 28, 2018 3:03:46 PM by Hibernate Tools 4.3.1

import java.util.HashSet;
import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:42:15 AM
 * 
 */
@SuppressWarnings("serial")
public class LandOwnershipDto implements java.io.Serializable {

	private Integer landOwnershipId;
	private String landOwnershipName;
	private Boolean status;
	private Set landDetailses = new HashSet(0);

	public LandOwnershipDto() {
		super();
	}

	public LandOwnershipDto(Integer landOwnershipId, String landOwnershipName, Boolean status, Set landDetailses) {
		super();
		this.landOwnershipId = landOwnershipId;
		this.landOwnershipName = landOwnershipName;
		this.status = status;
		this.landDetailses = landDetailses;
	}

	public Integer getLandOwnershipId() {
		return landOwnershipId;
	}

	public void setLandOwnershipId(Integer landOwnershipId) {
		this.landOwnershipId = landOwnershipId;
	}

	public String getLandOwnershipName() {
		return landOwnershipName;
	}

	public void setLandOwnershipName(String landOwnershipName) {
		this.landOwnershipName = landOwnershipName;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Set getLandDetailses() {
		return landDetailses;
	}

	public void setLandDetailses(Set landDetailses) {
		this.landDetailses = landDetailses;
	}

}
