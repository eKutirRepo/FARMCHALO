package ekutir.farmchaloApp.dto;

import java.util.Set;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:41:32 AM
 * 
 */
public class FarmerRegisterationDto {

	private int farmerId;
	private String firstName;
	private String lastName;
	private String mobileNo;
	private String nepalCitizenshipNumber;
	private String aadharNumber;
	private byte[] profilePic;
	private String address1;
	private int district;
	private String districtName;
	private String stateName;
	private String country;
	private String block;
	private String city;
	private int pinCode;
	private int userId;
	private String userName;
	private String latitude;
	private String longitude;
	private Set<LandDetailsDto> landDetailsDto;
	private StatusDto status;

	public FarmerRegisterationDto() {
		super();
	}

	public FarmerRegisterationDto(int farmerId, String firstName, String lastName, String mobileNo,
			String nepalCitizenshipNumber, String aadharNumber, byte[] profilePic, String address1, int district,
			String block, String city, int pinCode, int userId, String latitude, String longitude,
			Set<LandDetailsDto> landDetailsDto, StatusDto status) {
		super();
		this.farmerId = farmerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.nepalCitizenshipNumber = nepalCitizenshipNumber;
		this.aadharNumber = aadharNumber;
		this.profilePic = profilePic;
		this.address1 = address1;
		this.district = district;
		this.block = block;
		this.city = city;
		this.pinCode = pinCode;
		this.userId = userId;
		this.latitude = latitude;
		this.longitude = longitude;
		this.landDetailsDto = landDetailsDto;
		this.status = status;
	}

	public int getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getNepalCitizenshipNumber() {
		return nepalCitizenshipNumber;
	}

	public void setNepalCitizenshipNumber(String nepalCitizenshipNumber) {
		this.nepalCitizenshipNumber = nepalCitizenshipNumber;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public byte[] getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(byte[] profilePic) {
		this.profilePic = profilePic;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public int getDistrict() {
		return district;
	}

	public void setDistrict(int district) {
		this.district = district;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPinCode() {
		return pinCode;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public Set<LandDetailsDto> getLandDetailsDto() {
		return landDetailsDto;
	}

	public void setLandDetailsDto(Set<LandDetailsDto> landDetailsDto) {
		this.landDetailsDto = landDetailsDto;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}
