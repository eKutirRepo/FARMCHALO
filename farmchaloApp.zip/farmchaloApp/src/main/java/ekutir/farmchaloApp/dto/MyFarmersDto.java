package ekutir.farmchaloApp.dto;

import java.util.List;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:42:29 AM
 * 
 */
public class MyFarmersDto {

	private List<FarmerRegisterationDto> myFarmers;
	private StatusDto status;

	public MyFarmersDto() {
		super();
	}

	public MyFarmersDto(List<FarmerRegisterationDto> myFarmers, StatusDto status) {
		super();
		this.myFarmers = myFarmers;
		this.status = status;
	}

	public List<FarmerRegisterationDto> getMyFarmers() {
		return myFarmers;
	}

	public void setMyFarmers(List<FarmerRegisterationDto> myFarmers) {
		this.myFarmers = myFarmers;
	}

	public StatusDto getStatus() {
		return status;
	}

	public void setStatus(StatusDto status) {
		this.status = status;
	}

}
