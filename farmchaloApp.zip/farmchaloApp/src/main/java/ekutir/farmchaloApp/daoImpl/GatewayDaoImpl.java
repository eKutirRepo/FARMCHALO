package ekutir.farmchaloApp.daoImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ekutir.farmchaloApp.dao.GatewayDao;
import ekutir.farmchaloApp.model.AddressType;
import ekutir.farmchaloApp.model.CountryMaster;
import ekutir.farmchaloApp.model.DistrictMaster;
import ekutir.farmchaloApp.model.PhoneXOtp;
import ekutir.farmchaloApp.model.StateMaster;
import ekutir.farmchaloApp.model.User;
import ekutir.farmchaloApp.model.UserAddress;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:40:42 AM
 * 
 */
@Repository
public class GatewayDaoImpl implements GatewayDao {

	@Autowired
	CommonDaoImpl commonDao;

	@Override
	public List<User> fetchUserByMobileNo(String mobileNo) {
		try {
			return (List<User>) commonDao.getElementsByFieldName("mobileNo", mobileNo, User.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void saveOrUpdatePhoneXOtp(PhoneXOtp phoneXotp) {
//		System.out.println(".........");
		commonDao.saveOrUpdate(phoneXotp);
	}

	@Override
	public List<PhoneXOtp> fetchPhoneXOtpByMobileNo(String mobileNo) {
		try {
			return (List<PhoneXOtp>) commonDao.getElementsByFieldName("mobileNo", mobileNo, PhoneXOtp.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deletePhoneXOtp(PhoneXOtp phoneOTP) {
		commonDao.delete(phoneOTP);
	}

	@Override
	public User saveOrUpdateUser(User user) {
		User user1 = (User) commonDao.saveOrUpdate(user);
		Set<UserAddress> addressSet = new HashSet<UserAddress>();
		UserAddress uA = new ArrayList<UserAddress>(user1.getUserAddresses()).get(0);
		uA.setUser(user1);
		uA.setCreatedBy(user1.getUserId());
		addressSet.add(uA);
		user1.setCreatedBy(user1.getUserId());
		user1.setUserAddresses(addressSet);
		return (User) commonDao.saveOrUpdate(user1);
	}

	@Override
	public List<CountryMaster> fetchAllCountries() {
		return (List<CountryMaster>) commonDao.getAll(CountryMaster.class);
	}

	@Override
	public List<StateMaster> fetchAllStatesByCountryId(int countryMasterId) {
		return (List<StateMaster>) commonDao.getElementsByFieldName("countryMaster.countryMasterId", countryMasterId,
				StateMaster.class);
	}

	@Override
	public List<DistrictMaster> fetchDistrictByStateId(int stateMasterId) {
		return (List<DistrictMaster>) commonDao.getElementsByFieldName("stateMaster.stateMasterId", stateMasterId,
				DistrictMaster.class);
	}

	@Override
	public AddressType fetchAddressType(int i) {
		return (AddressType) commonDao.getElementsByFieldName("addressTypeId", 1, AddressType.class).get(0);
	}

	@Override
	public List<User> fetchUserByUserId(Integer userId) {
		return (List<User>) commonDao.getElementsByFieldName("userId", userId, User.class);
	}

	@Override
	public DistrictMaster fetchDistrictByDistrictId(int district) {
		return ((List<DistrictMaster>) commonDao.getElementsByFieldName("districtMasterId", district,
				DistrictMaster.class)).get(0);
	}

}
