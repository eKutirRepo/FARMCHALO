package ekutir.farmchaloApp.daoImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ekutir.farmchaloApp.dao.FarmerDao;
import ekutir.farmchaloApp.model.DistrictMaster;
import ekutir.farmchaloApp.model.IrrigationType;
import ekutir.farmchaloApp.model.LandAreaMasterUom;
import ekutir.farmchaloApp.model.LandDetails;
import ekutir.farmchaloApp.model.LandOwnership;
import ekutir.farmchaloApp.model.LandTypeMaster;
import ekutir.farmchaloApp.model.User;
import ekutir.farmchaloApp.model.UserAddress;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:40:36 AM
 * 
 */
@Repository
public class FarmerDaoImpl implements FarmerDao {

	@Autowired
	CommonDaoImpl commonDao;

	@Override
	public List<User> fetchUserByMobileNo(String mobileNo) {
		return (List<User>) commonDao.getElementsByFieldName("mobileNo", mobileNo, User.class);
	}

	@Override
	public User saveOrUpdateUser(User user) {
		User user1 = (User) commonDao.saveOrUpdate(user);

		Set<UserAddress> addressSet = new HashSet<UserAddress>();
		UserAddress uA = new ArrayList<UserAddress>(user1.getUserAddresses()).get(0);
		uA.setUser(user1);
		uA.setCreatedBy(user1.getUserId());
		addressSet.add(uA);
		user1.setCreatedBy(user1.getUserId());
		user1.setUserAddresses(addressSet);

		if (!user1.getLandDetailses().isEmpty()) {
			for (LandDetails landDetails : user1.getLandDetailses()) {
				landDetails.setUser(user1);
			}
		}

		return (User) commonDao.saveOrUpdate(user1);
	}

	@Override
	public List<IrrigationType> fetchAllIrrigationTypes() {
		return (List<IrrigationType>) commonDao.getElementsByFieldName("status", 1, IrrigationType.class);
	}

	@Override
	public List<LandAreaMasterUom> fetchAllLandAreaMasterUoms() {
		return (List<LandAreaMasterUom>) commonDao.getElementsByFieldName("status", 1, LandAreaMasterUom.class);
	}

	@Override
	public List<LandOwnership> fetchAllLandOwnerships() {
		return (List<LandOwnership>) commonDao.getElementsByFieldName("status", 1, LandOwnership.class);
	}

	@Override
	public List<LandTypeMaster> fetchAllLandTypeMasters() {
		return (List<LandTypeMaster>) commonDao.getElementsByFieldName("status", 1, LandTypeMaster.class);
	}

	@Override
	public List<User> fetchUserByUserId(int userId) {
		return (List<User>) commonDao.getElementsByFieldName("userId", userId, User.class);
	}

	@Override
	public List<User> fetchFarmersByMeId(int userId) {
		return (List<User>) commonDao.getElementsByFieldName("parentUserId", userId, User.class);
	}

	@Override
	public List<DistrictMaster> fetchDistrictByDistrictId(int district) {
		return (List<DistrictMaster>) commonDao.getElementsByFieldName("districtMasterId", district,
				DistrictMaster.class);
	}

}
