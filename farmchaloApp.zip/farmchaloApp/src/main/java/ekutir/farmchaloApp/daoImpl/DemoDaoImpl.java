package ekutir.farmchaloApp.daoImpl;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ekutir.farmchaloApp.dao.DemoDao;
import ekutir.farmchaloApp.model.Demo;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:40:28 AM
 * 
 */
@Transactional
@Repository
public class DemoDaoImpl implements DemoDao {

	@Autowired
	SessionFactory sessionFactory;
	
	Session session;

	@Override
	public void saveDemo(Demo demo) {
		session = sessionFactory.getCurrentSession();
		try {
		System.out.println("in Dao.....");
		sessionFactory.getCurrentSession().save(demo);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
