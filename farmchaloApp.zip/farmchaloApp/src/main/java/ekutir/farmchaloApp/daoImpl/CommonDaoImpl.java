package ekutir.farmchaloApp.daoImpl;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:40:20 AM
 * 
 */
@Transactional
@Repository
public class CommonDaoImpl {

	@Autowired
	SessionFactory sessionFactory;
	Session session;

	@SuppressWarnings({ "unchecked" })
	public <T> List<T> getAll(Class<T> entityClass) {
		try {
			return sessionFactory.getCurrentSession().createQuery("From " + entityClass.getName()).list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@SuppressWarnings({ "unchecked" })
	public <T> List<T> getElementsByFieldName(String fieldName, Object value, Class<T> entityClass) {
		session = sessionFactory.getCurrentSession();
		try {
			return session.createQuery("From " + entityClass.getName() + " where " + fieldName + " = " + value).list();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;
	}

	public <T> Object saveOrUpdate(Object entityClass) {
		session = sessionFactory.getCurrentSession();
		try {
			session.saveOrUpdate(entityClass);
			return entityClass;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void delete(Object entityClass) {
		session = sessionFactory.getCurrentSession();
		try {
			session.delete(entityClass);
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

}
