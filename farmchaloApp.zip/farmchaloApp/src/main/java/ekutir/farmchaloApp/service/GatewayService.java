package ekutir.farmchaloApp.service;

import ekutir.farmchaloApp.dto.CountryDto;
import ekutir.farmchaloApp.dto.CountryMasterDto;
import ekutir.farmchaloApp.dto.DistrictDto;
import ekutir.farmchaloApp.dto.PhoneXOtpDto;
import ekutir.farmchaloApp.dto.RegistrationDto;
import ekutir.farmchaloApp.dto.StateDto;
import ekutir.farmchaloApp.dto.StateMasterDto;
import ekutir.farmchaloApp.dto.StatusDto;
import ekutir.farmchaloApp.dto.UserDto;
import ekutir.farmchaloApp.model.PhoneXOtp;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:52 AM
 * 
 */
public interface GatewayService {

	PhoneXOtpDto generateOtp(PhoneXOtp phoneXotp);

	PhoneXOtpDto varifyOtp(PhoneXOtp phoneXotp);

	PhoneXOtpDto resendOtp(PhoneXOtp phoneXotp);

	UserDto registerUser(RegistrationDto registerationDto);

	CountryDto getAllCountries();

	StateDto getSateByCountry(CountryMasterDto countryMasterDto);

	DistrictDto getDistrictByState(StateMasterDto stateMasterdto);

	PhoneXOtpDto verifyMobileNo(PhoneXOtp phoneXotp);

	StatusDto forgetPassword(RegistrationDto registerationDto);

	UserDto login(RegistrationDto registrationDto);

	RegistrationDto meInfo(RegistrationDto registrationDto);

	RegistrationDto editInfo(RegistrationDto registrationDto);

}
