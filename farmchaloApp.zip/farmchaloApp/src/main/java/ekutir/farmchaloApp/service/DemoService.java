package ekutir.farmchaloApp.service;

import ekutir.farmchaloApp.model.Demo;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:46 AM
 * 
 */
public interface DemoService {

	void saveDemo(Demo demo);

}
