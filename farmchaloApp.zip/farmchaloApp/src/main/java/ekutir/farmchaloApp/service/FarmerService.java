package ekutir.farmchaloApp.service;

import ekutir.farmchaloApp.dto.FarmerRegisterationDto;
import ekutir.farmchaloApp.dto.LandAreaMasterUomDto;
import ekutir.farmchaloApp.dto.LandDetailsDto;
import ekutir.farmchaloApp.dto.LandDto;
import ekutir.farmchaloApp.dto.MyFarmersDto;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:44:59 AM
 * 
 */
public interface FarmerService {

	FarmerRegisterationDto farmerRegistration(FarmerRegisterationDto farmerRegistration);

	LandDto getLandInfo(LandAreaMasterUomDto landAreaMasterUomDto);

	MyFarmersDto fetchMyFarmers(FarmerRegisterationDto farmerRegistrationDto);

	FarmerRegisterationDto fetchFarmerInfo(FarmerRegisterationDto farmerRegistrationDto);

	LandDetailsDto addFarmersLand(LandDetailsDto landDetailsDto);

	FarmerRegisterationDto editFarmerInfo(FarmerRegisterationDto farmerRegistrationDto);

	LandDetailsDto editFarmerLand(LandDetailsDto landDetailsDto);

	
}
