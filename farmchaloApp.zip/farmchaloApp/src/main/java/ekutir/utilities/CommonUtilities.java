package ekutir.utilities;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import ekutir.farmchaloApp.dto.Otp2PlanResponse;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;

import javax.crypto.Cipher;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import static ekutir.farmchaloApp.configuration.AppConstants.*;

/**
 * @author Rutvij
 * @Date 31-Jul-2018 10:45:23 AM
 * 
 */

@SuppressWarnings("restriction")
public class CommonUtilities {

	@Autowired
	private AmazonS3 s3client;

	private static Logger logger = LoggerFactory.getLogger(CommonUtilities.class);

	static SimpleDateFormat outputFormat = null;
	static SimpleDateFormat inputFormat = null;
	static Date date = null;

	private static final byte[] _3desData = { (byte) 0x76, (byte) 0x6F, (byte) 0xBA, (byte) 0x39, (byte) 0x31,
			(byte) 0x2F, (byte) 0x0D, (byte) 0x4A, (byte) 0xA3, (byte) 0x90, (byte) 0x55, (byte) 0xFE, (byte) 0x55,
			(byte) 0x65, (byte) 0x61, (byte) 0x13, (byte) 0x34, (byte) 0x82, (byte) 0x12, (byte) 0x17, (byte) 0xAC,
			(byte) 0x77, (byte) 0x39, (byte) 0x19 };
	static SecretKeySpec _key = new SecretKeySpec(_3desData, "DESede");

	public static final Date currentDateTime() throws ParseException {
		outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		outputFormat.setTimeZone(TimeZone.getTimeZone(TIME_ZONE));
		return outputFormat.parse(outputFormat.format(new Date()));
	}

	public static final String encrypt(final String text) {
		byte[] plaintext = text.getBytes();

		try {
			Cipher cipher = Cipher.getInstance("DESede"); // Triple-DES
			cipher.init(Cipher.ENCRYPT_MODE, _key);

			byte[] cipherText = cipher.doFinal(plaintext);
			BASE64Encoder b64 = new BASE64Encoder();
			return b64.encode(cipherText);
		} catch (Exception e) {
			throw new java.lang.RuntimeException();
		}
	}

	public static String decrypt(final String text) {
		try {

			BASE64Decoder b64 = new BASE64Decoder();
			byte[] cipherText = b64.decodeBuffer(text);

			Cipher cipher = Cipher.getInstance("DESede"); // Triple-DES
			cipher.init(Cipher.DECRYPT_MODE, _key);

			String plainText = new String(cipher.doFinal(cipherText));
			return plainText;

		} catch (Exception e) {
			throw new java.lang.RuntimeException();
		}
	}

	public static int generateOtp() {
		return (int) (Math.random() * 9000) + 1000;
	}

	@SuppressWarnings("unused")
	public static boolean sendOtp(String mobileNo, int otp) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			// String otpdetails = "Your otp code is" + otp;
			Otp2PlanResponse otp2PlanResponse = restTemplate.getForObject(OTP_URL, Otp2PlanResponse.class, MESSAGE_API,
					mobileNo, otp);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	public static String fetchTimeInMilliSeconds() {
		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone(TIME_ZONE));
		return String.valueOf(cal.getTimeInMillis());
	}

	// public String uploadImageOnAWS(String profilePic) {
	// String url = "";
	// String fileName = fetchTimeInMilliSeconds() + AWS_FILE_FORMAT;
	// String bucketName = AWS_BUCKET_NAME;
	// try {
	//// File file = File.createTempFile("MyTempFile", ".png");
	//// BASE64Decoder decoder = new BASE64Decoder();
	//// byte[] decodedBytes = decoder.decodeBuffer(profilePic);
	//// BufferedImage image = ImageIO.read(new ByteArrayInputStream(decodedBytes));
	//// ImageIO.write(image, "png", file);
	//// file.deleteOnExit();
	//
	// File file = convertBS64ImgToFile(profilePic);
	//
	// System.out.println(bucketName + " " + fileName + file + " AWS");
	//
	// s3client.putObject(new PutObjectRequest(bucketName, fileName, file));
	// logger.info("===================== Upload File - Done!
	// =====================");
	//
	// url = AWS_DEFAULT_URL + bucketName + "/" + fileName;
	// return url;
	// } catch (AmazonServiceException ase) {
	// logger.info("Caught an AmazonServiceException from PUT requests, rejected
	// reasons:");
	// logger.info("Error Message: " + ase.getMessage());
	// logger.info("HTTP Status Code: " + ase.getStatusCode());
	// logger.info("AWS Error Code: " + ase.getErrorCode());
	// logger.info("Error Type: " + ase.getErrorType());
	// logger.info("Request ID: " + ase.getRequestId());
	// } catch (AmazonClientException ace) {
	// logger.info("Caught an AmazonClientException: ");
	// logger.info("Error Message: " + ace.getMessage());
	// }
	// return null;
	// }

	public static File convertBS64ImgToFile(String profilePic, String path) {
		try {
			System.out.println(path + "Images\\temp.png");
			File file = new File(path + "Images\\temp.png");
			BASE64Decoder decoder = new BASE64Decoder();
			byte[] decodedBytes = decoder.decodeBuffer(profilePic);
			BufferedImage image = ImageIO.read(new ByteArrayInputStream(decodedBytes));
			ImageIO.write(image, "png", file);
			file.deleteOnExit();
			return file;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	// public static void main(String args[]) {
	// String a= "Rutvij";
	// System.out.println(encrypt(a));
	// System.out.println(decrypt(encrypt(a)));
	//
	// }
}
